
echo "370+ TOOLS Download-Starting"

toilet -f slant -F gay "EasY_HacK"

git clone https://github.com/sabri-zaki/EasY_HaCk


echo  "4nonimizer"

toilet -f slant -F gay "4nonimizer"

git clone https://github.com/Hackplayers/4nonimizer.git

toilet -f mono12 -F metal "A-Rat" 

git clone  https://github.com/Xi4u7/A-Rat.git

toilet -f mono12 -F metal "ADB-Toolkit" 
   
git clone https://github.com/ASHWIN990/ADB-Toolkit.git

toilet -f mono12 -F metal "ATSCAN"

git clone https://github.com/AlisamTechnology/ATSCAN.git
    
toilet -f mono12 -F metal "AndroBugs_Framework"

git clone https://github.com/AndroBugs/AndroBugs_Framework.git

toilet -f mono12 -F metal  "Androspy" | lolcat
   
git clone https://github.com/TunisianEagles/Androspy.git
 
 toilet -f mono12 -F metal "AutoPixieWps"  | lolcat 
    
git clone https://github.com/nxxxu/AutoPixieWps.git

toilet -f mono12 -F metal  "Automater" | lolcat

git clone https://github.com/1aN0rmus/TekDefense-Automater.git

toilet -f mono12 -F metal   "Auxscan"  | lolcat 
   
git clone https://github.com/Gameye98/Auxscan.git
   
toilet -f mono12 -F meatl "BAF" | lolcat
    
git clone https://github.com/engMaher/BAF.git

toilet -f mono12 -F metal  "BadMod" | lolcat 
   
git clone https://github.com/MrSqar-Ye/BadMod.git
  
toilet -f mono12 -F metal  "BeeLogger" | lolcat 
   
git clone https://github.com/4w4k3/BeeLogger.git

toilet -f mono12 -F metal  "Black-Hydra" | lolcat

git clone https://github.com/Gameye98/Black-Hydra.git

toilet -f mono12 -F metal   "Blazy" | lolcat

git clone https://github.com/UltimateHackers/Blazy.git

toilet -f mono12 -F metal  "Breacher" | lolcat 
 
git clone https://github.com/UltimateHackers/Breacher.git

toilet -f mono12 -F metal "Brutal" | lolcat

git clone https://github.com/Screetsec/Brutal.git

toilet -f mono12 -F metal "BruteX" | lolcat 
   
git clone https://github.com/1N3/BruteX.git

toilet -f mono12 -F metal "CHAOS" | lolcat

git clone https://github.com/tiagorlampert/CHAOS.git

toilet -f mono12 -F metal "CMSeeK"  | lolcat 
 
git clone https://github.com/Tuhinshubhra/CMSeeK.git

toilet -f mono12 -F metal "CMSmap"

git clone https://github.com/Dionach/CMSmap.git
 
toilet -f mono12 -f metal  "CeWL"
   
git clone https://github.com/digininja/CeWL.git

toilet -f mono12 -F  "Clickjacking-Tester" 

git clone https://github.com/D4Vinci/Clickjacking-Tester.git

toilet -f mono12 -F metal  "Cookie-stealer" 
  
git clone https://github.com/Xyl2k/Cookie-stealer.git

toilet -f mono12 -F metal "CrawlBox"
   
git clone https://github.com/abaykan/CrawlBox.git
   
toilet -f mono12 -F metal  "CredSniper"

git clone https://github.com/ustayready/CredSniper.git

toilet -f mono12 -F metal "Crips"  

echo  "category" : ["information_gathering"

git clone https://github.com/Manisso/Crips.git

toilet -f mono12 -F metal "CyberScan"

git clone https://github.com/medbenali/CyberScan.git

toilet -f mono12 -F metal  "D-TECT" 

echo "category" "information_gathering","vulnerability_scanner"

git clone https://github.com/shawarkhanethicalhacker/D-TECT.git

toilet -f mono12 -F metal  "DHCPig"

echo   "category" "stress_testing"

git clone https://github.com/kamorin/DHCPig.git

toilet -f mono12 -F metal "DKMC"  

git clone https://github.com/Mr-Un1k0d3r/DKMC.git

toilet -f mono12 -F metal   "DSSS"

echo "category" : ["vulnerability_scanner"

git clone https://github.com/stamparm/DSSS.git

toilet -f mono12 -F metal  "DSVW" 

git clone https://github.com/stamparm/DSVW.git

toilet -f mono12 -F metal  "DSXS"

git clone https://github.com/stamparm/DSXS.git

toilet -f mono12 -F metal "Devploit"

echo    "category" : ["information_gathering"

git clone https://github.com/joker25000/Devploit.git

toilet -f mono12 -F metal "Dr0p1t-Framework"

git clone https://github.com/D4Vinci/Dr0p1t-Framework.git

toilet -f mono12 -F metal  "Dracnmap"  

git clone https://github.com/Screetsec/Dracnmap.git

toilet -f mono12 -F metal  "EagleEye"

git clone https://github.com/ThoughtfulDev/EagleEye.git

toilet -f mono12 -F metal  "EasY_HaCk" 

git clone https://github.com/sabri-zaki/EasY_HaCk.git

toilet -f mono12 -F metal "EggShell" 

git clone https://github.com/neoneggplant/EggShell.git

toilet -f mono12 -F metal "Email-Spammer" 

git clone https://github.com/Juniorn1003/Email-Spammer.git

toilet -f mono12 -F metal  "Empire"

git clone https://github.com/EmpireProject/Empire.git

toilet -f mono12 -F metal "EvilURL"

echo     "category" : ["information_gathering"

git clone https://github.com/UndeadSec/EvilURL.git

toilet -f mono12 -F metal   "ExploitOnCL"

echo    "category" : ["exploitation_tools"

git clone https://github.com/r00tmars/ExploitOnCLI.git

toilet -f mono12 -F metal   "EyeWitness"

echo    "category" : ["information_gathering"

git clone https://github.com/FortyNorthSecurity/EyeWitness.git

toilet -f mono12 -F metal   "FBUPv2.0"

git clone https://github.com/mrSilent0598/FBUPv2.0.git

toilet -f mono12 -F metal   "FakeImageExploiter"

git clone https://github.com/r00t-3xp10it/FakeImageExploiter.git

toilet -f mono12 -F metal   "Findsploit"

git clone https://github.com/1N3/Findsploit.git

toilet -f mono12 -F metal "Gemail-Hack"

git clone https://github.com/Ha3MrX/Gemail-Hack.git

toilet -f mono12 -F metal "Gloom-Framework"  

git clone https://github.com/StreetSec/Gloom-Framework.git

toilet -f mono12 -F metal  "GoblinWordGenerator" 

git clone https://github.com/UndeadSec/GoblinWordGenerator.git

toilet -f mono12 -F metal "GoldenEye"

echo     "category" : ["stress_testing"

git clone https://github.com/jseidl/GoldenEye.git

toilet -f mono12 -F metal   "HT-WPS-Breaker"

git clone https://github.com/SilentGhostX/HT-WPS-Breaker.git

toilet -f mono12 -F metal  "HTools" 

git clone https://github.com/mehedishakeel/HTools.git

toilet -f mono12 -F metal "Hash-Buster"

echo    "category" : ["password_attack"

git clone https://github.com/UltimateHackers/Hash-Buster.git

toilet -f mono12 -F metal "Hatch"

git clone https://github.com/MetaChar/Hatch.git

toilet -f mono12 -F metal "HiddenEye"

git clone https://github.com/DarkSecDevelopers/HiddenEye.git

toilet -f mono12 -F metal  "Hunner"

git clone https://github.com/b3-v3r/Hunner.git

toilet -f mono12 -F  "IP-FY"
 
echo     "category" : ["information_gathering"

git clone https://github.com/T4P4N/IP-FY.git

toilet -f mono12 -F metal   "IP-Locator"

git clone https://github.com/zanyarjamal/IP-Locator.git

toilet -f mono12 -F metal   "IP-Tracer"

git clone https://github.com/Rajkumrdusad/IP-Tracer

toilet -f mono12 -F metal   "IPGeoLocation"

git clone https://github.com/maldevel/IPGeoLocation.git

toilet -f mono12 -F metal   "InSpy"

git clone https://github.com/leapsecurity/InSpy.git
 
toilet -f mono12 -F  "Infoga"

echo     "category" : ["information_gathering"

git clone https://github.com/m4ll0k/Infoga.git

toilet -f mono12 -F metal  "Instahack" 

git clone https://github.com/avramit/Instahack.git
 
toilet -f mono12 -F metal "Intersect-2.5"

git clone https://github.com/deadbits/Intersect-2.5.git

toilet -f mono12 -F metal  "JohnTheRipper" 

echo     "category" : ["password_attack"

git clone https://github.com/magnumripper/JohnTheRipper.git


toilet -f mono12 -F metal  "JTRE" 

echo  "category" : ["password_attack"

git clone https://github.com/ASHWIN990/JTRE.git

toilet -f mono12 -F metal "KatanaFramework"

git clone https://github.com/PowerScript/KatanaFramework.git

toilet -f mono12 -F metal  "KnockMail" 

echo  "category" : ["sniffing_spoofing"

git clone https://github.com/4w4k3/KnockMail.git

toilet -f mono12 -F metal   "LALIN"

git clone https://github.com/Screetsec/LALIN.git

toilet -f mono12 -F metal   "LFISuite"

git clone https://github.com/D35m0nd142/LFISuite.git

toilet -f mono12 -F metal   "LITEDDOS"

git clone https://github.com/4L13199/LITEDDOS.git

toilet -f mono12 -F metal   "LITESPAM"

git clone https://github.com/4L13199/LITESPAM.git 

toilet -f mono12 -F metal   "Lazymux"

git clone https://github.com/Gameye98/Lazymux.git

toilet -f mono12 -F metal   "Leaked"

git clone https://github.com/GitHackTools/Leaked.git

toilet -f mono12 -F metal  "Mercury" 

git clone https://github.com/MetaChar/Mercury.git

toilet -f mono12 -F metal "Meterpreter_Paranoid_Mode-SSL"

echo "category" : ["exploitation_tools"

git clone https://github.com/r00t-3xp10it/Meterpreter_Paranoid_Mode-SSL.git

toilet -f mono12 -F metal   "MyServer"

git clone https://github.com/Rajkumrdusad/MyServer.git

toilet -f mono12 -F metal  "Nethunter-In-Termux"

git clone https://github.com/Hax4us/Nethunter-In-Termux.git

toilet -f mono12 -F metal "PadBuster"

git clone https://github.com/AonCyberLabs/PadBuster.git

toilet -f mono12 -F metal   "Parat"

git clone https://github.com/micle-fm/Parat.git

toilet -f mono12 -F metal   "Parsero"

echo     "category" : ["information_gathering"

git clone https://github.com/behindthefirewalls/Parsero.git

toilet -f mono12 -F metal  "PiDense"

git clone https://github.com/WiPi-Hunter/PiDense.git

toilet -f mono12 -F metal   "Planetwork-DDOS"

echo  "category" : ["ddos","stress_testing"
 
git clone https://github.com/Hydra7/Planetwork-DDOS.git

toilet -f mono12 -F metal  "PowerSploit" 

echo     "category" : ["maintaining_access"

git clone https://github.com/PowerShellMafia/PowerSploit.git

toilet -f mono12 -F metal   "PwnSTAR"

git clone https://github.com/SilverFoxx/PwnSTAR.git

toilet -f mono12 -F metal   "PyBozoCrack" 

git clone https://github.com/ikkebr/PyBozoCrack.git

toilet -f mono12 -F metal  "Pybelt"

git clone https://github.com/Ekultek/Pybelt.git

toilet -f mono12 -F metal  "Pyrit"

echo    "category" : ["wireless_testing"

git clone https://github.com/JPaulMora/Pyrit.git

toilet -f mono12 -F metal   "QRLJacking"

git conel https://github.com/OWASP/QRLJacking.git

toilet -f mono12 -F metal  "RED_HAWK"

echo "category" : ["information_gathering","vulnerability_scanner"

git clone https://github.com/Tuhinshubhra/RED_HAWK.git

toilet -f mono12 -F metal   "RTLSDR-Scanner"

echo  "category" : ["wireless_testing"

git clone https://github.com/EarToEarOak/RTLSDR-Scanner.git
  
toilet -f mono12 -F metal "ReconDog"

echo  "category" : ["information_gathering"

git clone https://github.com/UltimateHackers/ReconDog.git

toilet -f mono12 -F meatl  "RegRipper2.8"
 
echo  "category" : ["forensics_tools"

git clone https://github.com/keydet89/RegRipper2.8.git

toilet -f mono12 -F metal  "Remot3d"

git clone https://github.com/KeepWannabe/Remot3d.git

toilet -f mono12 -F metal "Responder"

echo  "category" : ["sniffing_spoofing"

git clone https://github.com/lgandx/Responder.git

toilet -f mono12 -F metal  "ReverseAPK"

git clone https://github.com/1N3/ReverseAPK.git

toilet -f mono12 -F metal "SCANNER-INURLBR"

echo  "category" : ["web_hacking"

git clone https://github.com/googleinurl/SCANNER-INURLBR.git

toilet -f mono12 -F metal  "SET"

echo "category" : ["information_gathering","exploitation_tools","password_attack","sniffing_spoofing"

git clone https://github.com/trustedsec/social-engineer-toolkit.git

toilet -f mono12 -F metal  "SMBrute"

git clone https://github.com/m4ll0k/SMBrute.git

toilet -f mono12 -F "SecLists"

echo  "category" : ["password_attack"

git clone https://github.com/danielmiessler/SecLists.git

toilet -f mono12 -F metal "Simple-Fuzzer"

echo  "category" : ["vulnerability_scanner"

git clone https://github.com/orgcandman/Simple-Fuzzer.git

toilet -f mono12 -F metal  "Sn1per"

git clone https://github.com/1N3/Sn1per.git

toilet -f mono12 -F metal "SocialBox" 

echo  "category" : ["sniffing_spoofing"

git clone https://github.com/TunisianEagles/SocialBox.git

toilet -f mono12 -F metal  "SocialFish" 

echo    "category" : ["password_attack","sniffing_spoofing"

git clone https://github.com/UndeadSec/SocialFish.git

toilet -f mono12 -F  metal  "Spammer-Email"
 
echo   "sniffing_spoofing"
git clone https://github.com/p4kl0nc4t/Spammer-Email.git

toilet -f mono12 -F metal  "Spammer-Grab"

echo    "category" : ["sniffing_spoofing"
git clone  https://github.com/p4kl0nc4t/Spammer-Grab.git

toilet -f mono12 -F metal  "Stitch"

git clone https://github.com/nathanlopez/Stitch.git

toilet -f mono12 -F metal  "Striker"

echo    "category" : ["vulnerability_scanner"

git clone https://github.com/s0md3v/Striker.git

toilet -f mono12 -F metal   "Sublist3r"

echo  "category" : ["information_gathering"

git clone https://github.com/aboul3la/Sublist3r.git

toilet -f mono12 -F metal  "TermuxAlpine"

echo    "category" : ["termux_os"

git clone https://github.com/Hax4us/TermuxAlpine.git

toilet -f mono12 -F metal   "Th3inspector"

git clone https://github.com/Moham3dRiahi/Th3inspector.git

toilet -f mono12 -F metal  "The-Eye"

git clone https://github.com/EgeBalci/The-Eye.git

toilet -f mono12 -F metal  "TheFatRat"

git clone https://github.com/Screetsec/TheFatRat.git

toilet -f mono12 -F metal  "Tool-X"

git clone https://github.com/Rajkumrdusad/Tool-X.git

toilet -f mono12 -F metal "TorStat"
 
git clone https://github.com/s0cket7/TorStat.git

toilet -f mono12 -F metal  "Trity"

git clone https://github.com/toxic-ig/Trity.git

toilet -f mono12 -F metal "Umbrella"

git clone https://github.com/4w4k3/Umbrella.git

toilet -f mono12 -F metal  "Vegile"
 
git clone https://github.com/Screetsec/Vegile.git

toilet -f mono12 -F metal "WAScan"

echo "category" : ["information_gathering","vulnerability_scanner","web_hacking"

git clone https://github.com/m4ll0k/WAScan.git

toilet -f mono12 -F metal "WP-plugin-scanner"

echo  "category" : ["web_hacking"

git clone https://github.com/mintobit/WP-plugin-scanner.git


toilet -f mono12 -F metal "WPSeku"

git clone https://github.com/m4ll0k/WPSeku.git

toilet -f mono12 -F metal  "WebScarab"

echo    "category" : ["web_hacking"

gif clone https://github.com/OWASP/OWASP-WebScarab.git

toilet -f mono12 -F metal "WebXploiter"

echo "category" : ["web_hacking","exploitation_tools"

git clone https://github.com/a0xnirudh/WebXploiter.git

toilet -f mono12 -F metal "WhatWeb"

echo  "category" : ["web_hacking"

git clone https://github.com/urbanadventurer/WhatWeb.git

toilet -f mono12 -F metal  "WiFi-Pumpkin"

echo  "category" : ["wireless_testing"

git clone https://github.com/P0cL4bs/WiFi-Pumpkin.git

toilet -f mono12 -F metal "WifiBruteCrack"

echo "category" : ["wireless_testing"

git clone https://github.com/cinquemb/WifiBruteCrack.git

toilet -f mono12 -F metal "Winpayloads"

git clone https://github.com/nccgroup/Winpayloads.git

toilet -f mono12 -F metal "XAttacker"

echo  "category" : ["vulnerability_scanner","web_hacking","exploitation_tools"

git clone https://github.com/Moham3dRiahi/XAttacker.git

toilet -f mono12 -F metal "XPL-SEARCH"

echo  "category" : ["web_hacking"

git clone https://github.com/r00tmars/XPL-SEARCH.git

toilet -f mono12 -F metal "XSStrike" 

echo  "category" "information_gathering","web_hacking"

git clone https://github.com/s0md3v/XSStrike.git

toilet -f mono12 -F metal "Xshell"

echo  "category" "vulnerability_scanner","web_hacking"

git clone https://github.com/Manisso/Xshell.git

toilet -f mono12 -F metal "Zerodoor"

git clone https://github.com/Souhardya/Zerodoor.git

toilet -f mono12 -F metal "admin-panel-finder"

echo   "category" "web_hacking"

git clone https://github.com/bdblackhat/admin-panel-finder.git

toilet -f mono12 -F "air-hammer"
 
git clone https://github.com/Wh1t3Rh1n0/air-hammer.git


echo "sunnam sriram"


toilet -f mono12 -F "airgeddon"

echo "category" "wireless_testing"

git clone https://github.com/v1s1t0r1sh3r3/airgeddon.git

toilet -f mono12 -F  "angryFuzzer" 

git clone https://github.com/ihebski/angryFuzzer.git


toilet -f mono12 -F "apt2"

echo  "category" "information_gathering"

git clone https://github.com/MooseDojo/apt2.git

toilet -f mono12 -F "arch-linux"

echo    "category" "termux_os"

curl https://raw.githubusercontent.com/sdrausty/TermuxArch/master/setupTermuxArch.sh

proot https://raw.githubusercontent.com/sdrausty/TermuxArch/master/setupTermuxArch.sh

toilet -f mono12 -F metal "arp-scan"

echo  "category" "information_gathering"

git clone https://github.com/royhills/arp-scan.git

toilet -f mono12 -F metal "avet" 

git clone https://github.com/govolution/avet.git

toilet -f mono12 -F  "bbqsql"

echo  "category" "vulnerability_scanner"

git clone https://github.com/Neohapsis/bbqsql.git

toilet -f mono12 -F metal  "bed"

echo "category" "vulnerability_scanner"

git clone https://gitlab.com/kalilinux/packages/bed.git

toilet -f mono12 -F metal "beef"

echo  "category" "exploitation_tools"

git clone https://github.com/beefproject/beef.git

toilet -f mono12 -F metal "bettercap"

echo  "category" "sniffing_spoofing"

git clone https://github.com/bettercap/bettercap.git

toilet -f mono12 -F metal "bing-ip2hosts"

echo   "category" "information_gathering"

git clone https://github.com/urbanadventurer/bing-ip2hosts.git

toilet -f mono12 -F metal "binwalk"

echo   "category" "forensics_tools"

git clone https://github.com/ReFirmLabs/binwalk.git

toilet -f mono12 -F metal "blackbox"

echo    "category" "vulnerability_scanner","exploitation_tools"

git clone https://github.com/jothatron/blackbox.git

toilet -f mono12 -F metal "bleachbit"

git clone https://github.com/bleachbit/bleachbit.git

toilet -f mono12 -F metal "braa"

echo    "category" "information_gathering"

git clone https://github.com/mteg/braa.git

toildt -f mono12 -F metal "brutespray"

git clone https://github.com/x90skysn3k/brutespray.git

toilet -f mono12 -F metal "bulk_extractor"

echo    "category" "forensics_tools"
git clone https://github.com/simsong/bulk_extractor.git

toilet -f mono12 -F metal "c++"

echo    "category" "Programming_language"

apt install c++
apt install c

toilet -f mono12 -F metal "capstone"

echo    "category" "forensics_tools"

git clone https://github.com/aquynh/capstone.git

toilet -f mono12 -F metal  "catphish"  

git clone https://github.com/ring0lab/catphish.git

toilet -f mono12 -F metal  "cdpsnarf" 

echo    "category" "information_gathering"

git clone https://github.com/Zapotek/cdpsnarf.git

tiolet -f mono12 -F metal  "clang"

echo  "category" "programming_language"

apt install clang 

toilet -f mono12 -F metal  "commix"

echo    "category" "exploitation_tools","web_hacking"

git clone https://github.com/commixproject/commix.git

toilet -f mono12 -F metal  "cowpatty"

echo  "category" "wireless_testing"

git clone https://github.com/joswr1ght/cowpatty.git

toilet -f mono12 -F metal  "cpscan"

git clone https://github.com/susmithHCK/cpscan.git

toilet -f mono12 -F metal "crackle"

echo  "category" "exploitation_tools","wireless_testing"

git clone https://github.com/mikeryan/crackle.git


toilet -f mono12 -F  "creddump"

echo  "category" "password_attack"

git clone https://github.com/moyix/creddump.git

toilet -f mono12 -F   "credmap"

git clone https://github.com/lightos/credmap.git

toilet -f mono12 -F  "crowbar"

echo  "category" "password_attack"

git clone https://github.com/galkan/crowbar.git

toilet -f mono12 -F "cuckoo"

echo  "category" "forensics_tools"

git clone https://github.com/cuckoosandbox/cuckoo.git

toilet -f mono12 -F metal  "cupp"

echo  "category" "password_attack"

git clone https://github.com/Mebus/cupp.git

toilet -f mono12 -F metal  "curl"

apt install curl

toilet -f mono12 -F metal  "c + clang"

echo "category" "programming_language"

apt install clang 

apt install c

toilet -f mono12 -F metal "dbd"  

echo  "category" "maintaining_access"

git clone https://github.com/gitdurandal/dbd.git

toilet -f mono12 -F metal  "deblaze"

echo  "category" "web_hacking"

git clone https://github.com/SpiderLabs/deblaze.git

toilet -f mono12 -F  "dedsploit" 
 
git clone https://github.com/ex0dus-0x/dedsploit.git

toilet -f mono12 -F  "demiguise"

git clone https://github.com/nccgroup/demiguise.git

toilet -f mono12 -F metal  "distorm"

echo  "category" "forensics_tools"

git clone https://github.com/gdabah/distorm.git

toilet -f mono12 -F   "djangohunter"  

git clone https://github.com/6IX7ine/djangohunter.git

toilet -f mono12 -F metal "dmitry"

echo   "category" "information_gathering"

git clone https://github.com/jaygreig86/dmitry.git

toilet -f mono12 -F metal "dnschef"

echo  "category" "sniffing_spoofing"

git clone https://gitlab.com/kalilinux/packages/dnschef.git

toilet -f mono12 -F metal  "dnsenum"

echo  "category" "information_gathering"

git clone https://github.com/fwaeytens/dnsenum.git

toilet -f mono12 -F metal "dnsmap" 

echo  "category" "information_gathering"

git clone https://github.com/makefu/dnsmap.git

toilet -f mono12 -F metal  "dnsrecon"

echo   "category" "information_gathering"

git clone https://github.com/darkoperator/dnsrecon.git

toilet -f mono12 -F metal  "doona"

echo "category" "vulnerability_scanner"

git clone https://github.com/wireghoul/doona.git

toilet -f mono12 -F metal "doork" 

echo  "category" "information_gathering","web_hacking"

git clone https://github.com/AeonDave/doork.git

toilet -f mono12 -F metal  "dotdotpwn" 

echo "category" "information_gathering","vulnerability_scanner"

git clone https://github.com/wireghoul/dotdotpwn.git

toilet -f mono12 -F metal "dumpzilla"

echo   "category" "forensics_tools"

git clone https://gitlab.com/kalilinux/packages/dumpzilla.git

toilet -f mono12 -F metal "eaphammer" 

git clone https://github.com/s0lst1c3/eaphammer.git

toilet -f mono12 -F metal  "elpscrk"

git clone https://github.com/D4Vinci/elpscrk.git

toilet -f mono12 -F metal  "enum4linux"

echo  "category" "information_gathering"

git clone https://github.com/portcullislabs/enum4linux.git

toilet -f mono12 -F metal  "eternal_scanner"

git clone https://github.com/peterpt/eternal_scanner.git

toilet -f mono12 -F metal "evilginx"

git clone https://github.com/kgretzky/evilginx.git

toilet -f mono12 -F metal  "exploitdb"

echo  "category" "exploitation_tools"

git clone https://github.com/offensive-security/exploitdb.git

toilet -f mono12 -F metal "extundelete"

echo  "category" "forensics_tools"

git clone https://gitlab.com/kalilinux/packages/extundelete.git

toilet -f mono12 -F metal  "ezsploit"

git clone https://github.com/rand0m1ze/ezsploit.git

toilet -f mono12 -F "faraday"
 
echo   "category" "information_gathering"

git clone https://github.com/infobyte/faraday.git

toilet -f mono12 -F metal  "fbht" 

git clone https://github.com/chinoogawa/fbht.git

toilet -f mono12 -F metal "fbvid"

git clone https://github.com/Tuhinshubhra/fbvid.git

toilet -f mono12 -F metal "fern-wifi-cracker"
 
echo  "category" "wireless_testing"

git clone https://github.com/savio-code/fern-wifi-cracker.git

toilet -f mono12 -F metal  "fierce" 

echo   "category" "information_gathering"

git clone https://github.com/mschwager/fierce.git

toilet -f mono12 -F metal "figlet" 
 
apt install figlet

toilet -f mono12 -F metal "findmyhash"

echo  "category" "password_attack"

git clone https://gitlab.com/kalilinux/packages/findmyhash.git

toilet -f mono12 -F metal  "firewalk"

echo "category" "information_gathering"

git clone https://gitlab.com/kalilinux/packages/firewalk.git

toilet -f mono12 -F metal  "fluxion"

echo  "category" "wireless_testing"

git clone https://github.com/FluxionNetwork/fluxion.git
 
toilet -f mono12 -F metal "foremost"

echo    "category" "forensics_tools"
git clone https://gitlab.com/kalilinux/packages/foremost.git

toilet -f mono12 -F metal  "fragrouter"

echo  "category" "information_gathering"

git clone https://gitlab.com/kalilinux/packages/fragrouter.git

toilet -f mono12 -F metal  "fragroute"

echo  "category" "information_gathering"

git clone https://gitlab.com/kalilinux/packages/fragroute.git

toilet -f mono12 -F metal  "fsociety"

git clone https://github.com/Manisso/fsociety.git

toilet -f mono12 -F metal "fuckshitup"

git clone https://github.com/Smaash/fuckshitup.git

toilet -f mono12 -F metal "fuxploider"

git clone https://github.com/almandin/fuxploider.git

toilet -f mono12 -F   "gasmask"
 
git clone https://github.com/twelvesec/gasmask.git


toilet -f mono12v -F   "gcat"

git clone https://github.com/byt3bl33d3r/gcat.git

toilet -f mono12 -F metal  "get"

git clone https://github.com/peterpt/get.git

toilet -f mono12 -F metal "ghost-phisher"

echo  "category" : ["information_gathering"

git clone https://github.com/savio-code/ghost-phisher.git

toilet -f mono12 -F  "giskismet"

echo  "category" : ["wireless_testing"

git clone https://github.com/xtr4nge/giskismet.git

toilet -f mono12 -F metal  "git"

apt install git 

toilet -f mono12 -F metal "gobuster"

echo  "category" : ["web_hacking"

git clone https://github.com/OJ/gobuster.git

toilet -f mono12 -F metal "golang"

echo  "category" : ["programming_language"

apt install golang

toilet -f mono12 -F metal  "golismero" 

echo "category" : ["information_gathering"

git clone https://github.com/golismero/golismero.git

toilet -f mono12 -F metal "goofile"

echo  "category" : ["information_gathering"

git clone https://gitlab.com/kalilinux/packages/goofile.git

toilet -f mono12 -F metal "gcc"

echo "category" : ["programming_language"

apt install gcc

toilet -f mono12 -F metal "hURL"

echo  "category" : ["web_hacking"

git clone https://github.com/fnord0/hURL.git

toilet -f mono12 -F metal  "hacktronian"

git clone https://github.com/thehackingsage/hacktronian.git

toilet -f mono12 -F metal  "hakkuframework"

git clone https://github.com/4shadoww/hakkuframework.git

toilet -f mono12 -F metal  "hammer"

echo   "category" : ["ddos"

git clone https://github.com/cyweb/hammer.git

toilet -f mono12 -F metal "hash-generator"

echo  "category" : ["password_attack"

git clone https://github.com/CiKu370/hash-generator.git

toilet -f mono12 -F metal "hashcat"

echo  "category" : ["password_attack"

git clone https://github.com/hashcat/hashcat.git

toilet -f mono12 -F metal "hasherdotid"

echo   "category" : ["password_attack"

git clone https://github.com/galauerscrew/hasherdotid.git

toilet -f mono12 -F metal "hasher"

echo  "category" : ["password_attack"

git clone https://github.com/CiKu370/hasher.git

toilet -f mono12 -F "httptunnel"

echo   "category" : ["maintaining_access"

git clone https://github.com/larsbrinkhoff/httptunnel.git

toilet -f mono12 -F metal "hulk"

echo  "category" : ["ddos"

git clone https://github.com/grafov/hulk.git

toilet -f mono12 -F metal "hydra"

echo "category" : ["stress_testing","password_attack"

apt install hydra

toilet -f mono12 -F metal "iSMTP"

echo  "category" : ["information_gathering"

git clone https://github.com/altjx/ipwn.git

toilet -f mono12 -F metal "intrace"

echo  "category" : ["information_gathering"

git clone https://github.com/robertswiecki/intrace.git

toilet -f mono12 -F metal "jboss-autopwn"

git clone https://github.com/SpiderLabs/jboss-autopwn.git

toilet -f mono12 -F metal "johnny"

echo  "category" : ["password_attack"

git clone https://github.com/shinnok/johnny.git

toilet -f mono12 -F metal "joomscan"

echo  "category" : ["web_hacking"

git clone https://github.com/rezasp/joomscan.git

toilet -f mono12 -F metal "jsql-injection"

echo  "category" : ["vulnerability_scanner"

git clone https://github.com/ron190/jsql-injection.git

toilet -f mono12 -F metal "kalibrate-rtl"

echo  "category" : ["wireless_testing"

git clone https://github.com/steve-m/kalibrate-rtl.git

toilet -f mono12 -F metal "keimpx"

echo  "category" : ["password_attack"

git clone https://github.com/inquisb/keimpx.git

toilet -f mono12 -F metal "kickthemout" 

echo "category" : ["wireless_testing"

git clone https://github.com/k4m4/kickthemout.git

toilet -f mono12 -F metal "killchain"

git clone https://github.com/ruped24/killchain.git

toilet -f mono12 -F metal "killerbee"

echo  "category" : ["wireless_testing"

git clone https://github.com/riverloopsec/killerbee.git

echo "dependency" : ["perl","python","sunnam1","clang","gcc","g++","ruby","git"

toilet -f mono12 -F metal "killshot"

git clone https://github.com/bahaabdelwahed/killshot.git

toilet -f mono12 -F metal "koadic"

git clone https://github.com/zerosum0x0/koadic.git

toilet -f mono12 -F metal "kwetza"

git clone https://github.com/sensepost/kwetza.git

toilet -f mono12 -F metal "leviathan"

git clone https://github.com/tearsecurity/leviathan.git

toilet -f mono12 -F metal "lscript"

git clone https://github.com/arismelachroinos/lscript.git

toilet -f mono12 -F metal "lynis"

echo  "category" : ["vulnerability_scanner"

git clone https://github.com/CISOfy/lynis.git

toilet -f mono12 -F   "maskprocessor"

echo  "category" : ["password_attack"

git clone https://github.com/hashcat/maskprocessor.git

toilet -f mono12 -F metal "masscan"

echo "category" : ["information_gathering"

git clone https://github.com/robertdavidgraham/masscan.git

toilet -f mono12 -F metal "metasploit-framework"

echo  "category" : ["exploitation_tools"

curl https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb

toilet -f mono12 -F metal "mfcuk" 

echo "category" : ["wireless_testing"

git clone https://github.com/nfc-tools/mfcuk.git

toilet -f mono12 -F metal "mfoc"

echo "category" : ["wireless_testing"

git clone https://github.com/nfc-tools/mfoc.git

toilet -f mono12 -F metal "mfterm"

echo "category" : ["wireless_testing"

git clone https://github.com/4ZM/mfterm.git

toilet -f mono12 -F metal "mitmproxy"

echo  "category" : ["sniffing_spoofing"

git clone https://github.com/mitmproxy/mitmproxy.git
 
toilet -f mono12 -F metal  "morpheus"

git clone https://github.com/r00t-3xp10it/morpheus.git

toilet -f mono12 -F metal  "msfpc"

echo  "category" : ["exploitation_tools"

git clone https://github.com/g0tmi1k/msfpc.git

toilet -f mono12 -F  "multimon-ng"

echo "category" : ["wireless_testing"

git clone https://github.com/EliasOenal/multimon-ng.git

toilet -f mono12 -F metal "nWatch"

git clone https://github.com/s0cket7/nWatch.git

toilet -f mono12 -F metal "nano"

apt install nano

toilet -f mono12 -F metal "netattack2"

echo  "category" : ["wireless_testing"

git clone https://github.com/chrizator/netattack2.git

toilet -f mono12 -F metal  "netattack"

echo "category" : ["wireless_testing"

git clone https://github.com/chrizator/netattack.git

toilet -f mono12 -F metal  "netdiscover"

git clone https://github.com/alexxy/netdiscover.git

toilet -f mono12 -F metal "nginx"

apt install nginx

toilet -f mono12 -F metal "nikto"

echo "category" : ["information_gathering"

git clone https://github.com/sullo/nikto.git

toilet -f mono12 -F metal  "nishang"

echo  "category" : ["maintaining_access"

git clone https://github.com/samratashok/nishang.git

toilet -f mono12 -F metal "nmap"

echo "category" : ["information_gathering","vulnerability_scanner"

toilet -f mono12 -F metal "nodejs"

echo "category" : ["programming_language"

apt install nodejs

toilet -f mono12 -F metal "nodexp"

git clone https://github.com/esmog/nodexp.git

toilet -f mono12 -F metal "noisy"
 
git clone https://github.com/1tayH/noisy.git

toilet -f mono12 -F metal "onioff" 

git clone https://github.com/k4m4/onioff.git

toilet -f mono12 -F metal "openvas"

echo  "category" : ["vulnerability_scanner"

git clone https://github.com/greenbone/openvas.git

toilet -f mono12 -F metal  "osrframework"

echo  "category" : ["information_gathering"

git clone https://github.com/i3visio/osrframework.git

toilet -f mono12 -F matel  "p0f"

echo "category" : ["forensics_tools"

git clone https://gitlab.com/kalilinux/packages/p0f.git

toilet -f mono12 -F metal "patator"

echo   "category" : ["password_attack"

git clone https://gitlab.com/kalilinux/packages/patator.git

toilet -f mono12 -F metal "pdf-parser"

echo  "category" : ["forensics_tools"

git clone https://gitlab.com/kalilinux/packages/pdf-parser.git

toilet -f mono12 -F metal "peepdf"

git clone https://github.com/jesparza/peepdf.git

toilet -f mono12 -F metal "perl"

echo "category" : ["programming_language"

apt install perl

toilet -f mono12 -F "php" 

apt install php

toilet -f mono12 -F metal "pixiewps"

echo  "category" : ["wireless_testing"

git clone https://github.com/wiire-a/pixiewps.git

toilet -f mono12 -F metal "plecost"

echo  "category" : ["web_hacking"

git clone https://github.com/iniqua/plecost.git

toilet -f mono12 -F metal "powerfuzzer"

echo  "category" : ["vulnerability_scanner"

git clone https://gitlab.com/marcinguy/powerfuzzer.git

toilet -f mono12 -F metal "proxystrike"

echo  "category" : ["web_hacking"

git clone https://github.com/qunxyz/proxystrike.git

toilet -f mono12 -F metal "pupy"

git clone https://github.com/n1nj4sec/pupy

toilet -f mono12 -F metal "pwnat"

echo  "category" : ["maintaining_access"

git clone https://github.com/samyk/pwnat.git

toilet -f mono12 -F metal "pyPISHER"

echo  "category" : ["sniffing_spoofing"

git clone https://github.com/Renato-Silva/pyPISHER.git

toilet -f mono12 -F metal "pybluez" 

git clone https://github.com/karulis/pybluez.git
 
toilet -f mono12 -F metal "pydictor"

git clone https://github.com/LandGrey/pydictor.git

toilet -f mono12 -F metal "python"

apt install python
apt install python2
apt install python3

toilet -f mono12 -F metal "qark" 
 
git clone https://github.com/linkedin/qark.git

toilet -f mono12 -F metal "rang3r"

echo   "category" : ["vulnerability_scanner"

git clone https://github.com/floriankunushevci/rang3r.git

toilet -f mono12 -F metal "rdpy"

git clone https://github.com/citronneur/rdpy.git

toilet -f mono12 -F  "reaver"

echo  "category" : ["wireless_testing"

git clone https://github.com/t6x/reaver-wps-fork-t6x.git

toilet -f mono12 -F metal  "recon-ng"

echo  "category" : ["information_gathering"

git clone https://github.com/lanmaster53/recon-ng.git

toilet -f mono12 -F  "ridenum"

echo "category" : ["maintaining_access"

git clone https://github.com/trustedsec/ridenum.git

toilet -f mono12 -F "routersploit"

echo "category" : ["vulnerability_scanner","exploitation_tools"

git clone https://github.com/reverse-shell/routersploit.git

toilet -f mono12 -F metal "roxysploit"

echo "category" : ["exploitation_tools"

git clone https://github.com/andyvaikunth/roxysploit.git

toilet -f mono12 -F metal "ruby"

apt install ruby

toilet -f mono12 -F metal "sAINT"

git clone https://github.com/tiagorlampert/sAINT.git

toilet -f mono12 -F metal "santet-online"

echo "category" : ["stress_testing","sniffing_spoofing"

git clone https://github.com/Gameye98/santet-online.git

toilet -f mono12 -F metal "secHub"

git clone https://github.com/cys3c/secHub.git

toilet -f mono12 -F metal "shellnoob"

echo  "category" : ["exploitation_tools"

git clone https://github.com/reyammer/shellnoob.git

toilet -f mono12 -F metal "shellstack"
 
git clone https://github.com/Tuhinshubhra/shellstack.git

toilet -f mono12 -F metal "shimit"

git clone https://github.com/cyberark/shimit.git

toilet -f mono12 -F metal "shodanwave"

git clone https://github.com/6IX7ine/shodanwave.git

toilet -f mono12 -F metal "sipvicious"

echo  "category" : ["sniffing_spoofing"

git clone https://github.com/EnableSecurity/sipvicious.git

toilet -f mono12  -F metal "skipfish"

git clone https://gitlab.com/kalilinux/packages/skipfish.git

toilet -f mono12 -F "slowhttptest"

echo "category" : ["stress_testing"

git clone https://github.com/shekyan/slowhttptest.git

toilet -f mono12 -F metal  "slowloris" 

git clone https://github.com/gkbrk/slowloris.git

toilet -f mono12 -F metal "smap"

echo  "category" : ["web_hacking"

git clone https://github.com/s0cket7/smap

toilet -f mono12 -F metal "smbmap"

echo   "category" : ["information_gathering"

git clone https://github.com/ShawnDEvans/smbmap.git

toilet -f mono12 -F metal  "sniffjoke"

echo    "category" : ["sniffing_spoofing"

git clone https://github.com/vecna/sniffjoke.git

echo    "dependency" : ["clang","gcc","g++","git"

toilet -f mono12 -F metal  "social-engineer-toolkit"

echo  "category" : ["information_gathering","exploitation_tools","password_attack","sniffing_spoofing"

git clone https://github.com/trustedsec/social-engineer-toolkit.git

toilet -f momo12 -F metal "sqliv"

echo "category" : ["vulnerability_scanner","web_hacking"

git clone https://github.com/Hadesy2k/sqliv.git

toilet -f mono12 -F metal  "sqlmap"

echo  "category" : ["information_gathering","vulnerability_scanner","exploitation_tools","web_hacking"

git clone https://github.com/sqlmapproject/sqlmap

toilet -f mono12 -F metal "sqlmate"

echo "category" : ["information_gathering","vulnerability_scanner","web_hacking"

git clone https://github.com/s0md3v/sqlmate.git

toilet -f mono12 -F metal "sqlscan"

echo "category" : ["information_gathering","vulnerability_scanner","web_hacking"

git clone https://github.com/Cvar1984/sqlscan.git

toilet -f mono12 -F metal "sslcaudit"

echo "category" : ["information_gathering"

git clone https://github.com/abbbe/sslcaudit.git

toilet -f mono12 -F metal "sslsplit"

echo  "category" : ["information_gathering"

git clone https://github.com/droe/sslsplit.git

toilet -f mono12 -F metal "sslstrip"

echo  "category" : ["information_gathering","sniffing_spoofing"

git clone https://github.com/moxie0/sslstrip.git

toilet -f mono12 -F metal "sslyze"

echo "category" : ["information_gathering"

git clone https://github.com/iSECPartners/sslyze.git

toilet -f mono12 -F metal "subscraper"

git clone https://github.com/m8r0wn/subscraper.git

toilet -f mono12 -F "termineter"

echo "category" : ["stress_testing"

git clone https://github.com/securestate/termineter.git

toilet -f mono12 -F metal "termux-fedora"
 
git clone https://github.com/nmilosev/termux-fedora.git
 
toilet -f mono12 -F metal "termux-lazysqlmap"

git clone https://github.com/verluchie/termux-lazysqlmap.git

toilet -f mono12 -F metal "termux-ubuntu"
 
git clone https://github.com/Neo-Oli/termux-ubuntu.git

toilet -f mono12 -F metal "thc-ipv6"

echo "category" : ["information_gathering","vulnerability_scanner","exploitation_tools"

git clone https://github.com/vanhauser-thc/thc-ipv6.git

toilet -f mono12 -F metal "the-backdoor-factory"

echo    "category" : ["exploitation_tools"

git clone https://github.com/secretsquirrel/the-backdoor-factory.git

toilet -f mono12 -F metal "theHarvester"

echo  "category" : ["information_gathering"

git clone https://github.com/laramies/theHarvester.git

toilet -f mono12 -F metal "toilet"

apt install toilet


toilet -f mono12 -F metal "torghost"
 
git clone https://github.com/susmithHCK/torghost.git
 
toilet -f mono12 -F metal "torshammer"

echo   "category" : ["stress_testing"

git clone https://github.com/dotfighter/torshammer.git

toilet -f mono12 -F mono12 "tor"

apt install tor

toilet -f mono12 -F metal  "trackout"

echo "category" : ["information_gathering","ip_tracking"

git clone https://github.com/abaykan/trackout.git

toilet -f mono12 -F metal "trape"

git clone https://github.com/boxug/trape.git

toilet -f mono12 -F metal "trojanizer"
 
git clone https://github.com/r00t-3xp10it/trojanizer.git

toilet -f mono12 -F metal "txtool"

git clone https://github.com/kuburan/txtool.git

toilet -f mono12 -F metal "uidsploit"

git clone https://github.com/siruidops/uidsploit.git

toilet -f mono12 -F metal "volatility"
 
git clone https://github.com/volatilityfoundation/volatility.git

toilet -f mono12 -F metal  "w3af"

echo    "category" : ["web_hacking"

git clone https://github.com/andresriancho/w3af.git

toilet -f mono12 -F metal "w3m"

apt install w3m

toilet -f mono12 -F metal  "wafw00f"
 
git clone https://github.com/EnableSecurity/wafw00f.git

toilet -f mono12 -F metal  "webdav"

git clone https://github.com/hacdias/webdav.git

toilet -f mono12 -F metal "webpwn3r"
 
git clone https://github.com/zigoo0/webpwn3r.git

toilet -f mono12 -F metal "websploit"

echo    "category" : ["web_hacking" "exploitation_tools"

git clone https://github.com/websploit/websploit.git

toilet -f mono12 -F metal "weeman"
 
git clone https://github.com/evait-security/weeman.git

toilet -f mono12 -F metal  "weevely3"
 
git clone https://github.com/epinna/weevely3.git

toilet -f mono12 -F metal "wfdroid-termux" 

git clone https://github.com/bytezcrew/wfdroid-termux.git

toilet -f mono12 -F metal "wfuzz"

echo "category" : ["web_hacking"

git clone https://github.com/xmendez/wfuzz.git
 
toilet -f mono12 -F metal  "wget"

apt install wget

toilet -f mono12 -F metall "wifi-hacker"

git clone https://github.com/esc0rtd3w/wifi-hacker.git

toielt -f mono12 -F "WifiGod"

git clone https://github.com/waseem-sajjad/WifiGod.git

toilet -f mono12 -F  "wifiphisher"

git clone https://github.com/wifiphisher/wifiphisher.git

toilet -f mono12 -F metal "wifitap"
 
git clone https://github.com/GDSSecurity/wifitap.git

toilet -f mono12 -F metal "wifite2"
 
git clone https://github.com/derv82/wifite2.git

toilet -f mono12 -F metal "wifite"  

git clone https://github.com/derv82/wifite.git

toilet -f mono12 -F metal  "wifresti"
 
https://github.com/LionSec/wifresti.git

toilet -f mono12 -F metal "wirespy"
 
git clone https://github.com/AresS31/wirespy.git

toilet -f mono12 -F metal "wpscan"

echo "category" : ["information_gathering","vulnerability_scanner","web_hacking"

git clone https://github.com/wpscanteam/wpscan.git

toilet -f mono12 -F metal "wreckuests"

git clone https://github.com/JamesJGoodwin/wreckuests.git

toilet -f mono12 -F metal "xerosploit"
 
git clone https://github.com/LionSec/xerosploit.git

toilet -f mono12 -F metal "xplico"

git clone https://gitlab.com/kalilinux/packages/xplico.git

toilet -f mono12 -F metal "xspy"

echo    "category" : ["sniffing_spoofing"

git clone https://github.com/mnp/xspy.git

toilet -f mono12 -F metal "xsser"

echo "category" : ["web_hacking"

git clone https://github.com/epsylon/xsser.git

toilet -f mono12 -F metal "yersinia"

echo    "category" : ["vulnerability_scanner","exploitation_tools"

git clone https://github.com/tomac/yersinia.git

toilet -f mono12 -F metal  "zambie"

git clone https://github.com/zanyarjamal/zambie.git

toilet -f mono12 -F metal "zaproxy"

echo "category" : ["web_hacking"

git clone https://github.com/zaproxy/zaproxy.git

toilet -f mono12 -F metal "zarp"

git clone https://github.com/hatRiot/zarp.git

toilet -f mono12 -F metal "zip"
 
apt install zip

toilet -f mono12 -F metal "zirikatu"

git clone https://github.com/pasahitz/zirikatu.git

toilet -f mono12 -F metal "a-xex"

echo  "category" : ["web_hacking","exploitation_tools","information_gathering","vulnerability_scanner"

git clone https://github.com/farinap5/A-xex.git

toilet -f mono12 -F metal "rsfac"

echo  "category" : ["web_hacking","exploitation_tools"

git clone https://github.com/farinap5/rsfac.git

