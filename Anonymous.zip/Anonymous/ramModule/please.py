import os, sys

print ("\033[1;32m    UserName&Password:)")
print ("\033[1;31m    Mr.SUNNAM sriram +918688655324")
username = 'john001'      
password = 'john001'

def restart():
	ngulang = sys.executable
	os.execl(ngulang, ngulang, *sys.argv)

def main():
	uname = raw_input("Username : ")
	if uname == username:
		pwd = raw_input("Password : ")

		if pwd == password:
			print "Hello Welcome To 200Tools Ram.sh", 
			sys.exit()

		else:
			print "Sorry Invalid Password !!!"
			print "Back Login\n"
			restart()

	else:
		print "Sorry Invalid Username !!!"
		print "Back Login\n"
		restart()

try:
	main()
except KeyboardInterrupt:
	os.system('clear')
	restart()
